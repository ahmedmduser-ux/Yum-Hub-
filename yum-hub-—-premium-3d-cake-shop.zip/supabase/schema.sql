-- ========================================================================
-- YUM HUB — Supabase Database Migration & Secure RLS Policies
-- ========================================================================
-- Description:
-- Production PostgreSQL schema for YUM HUB 3D Cake Shop.
-- Enforces server-side authentication, role-based access control (RBAC),
-- order protection, and product management with Row Level Security.
-- ========================================================================

-- 1. Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ========================================================================
-- TABLE: user_roles
-- Stores RBAC roles for Supabase auth users.
-- Prevents unauthorized users from escalating privileges.
-- ========================================================================
CREATE TABLE IF NOT EXISTS public.user_roles (
    user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (role IN ('owner', 'admin', 'customer')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- Index for fast role lookups
CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON public.user_roles(user_id);

-- Enable Row Level Security (RLS) on user_roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Helper security definer function to test if a given user is an owner
-- Security definer allows this function to check roles without recursive policy loops
CREATE OR REPLACE FUNCTION public.is_owner(check_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
    SELECT EXISTS (
        SELECT 1
        FROM public.user_roles
        WHERE user_id = check_user_id
          AND role = 'owner'
    );
$$;

-- RLS: Authenticated user can read their own role record
CREATE POLICY "Users can read own role"
ON public.user_roles
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

-- RLS: Only confirmed owners can manage roles
CREATE POLICY "Owners can manage all roles"
ON public.user_roles
FOR ALL
TO authenticated
USING (public.is_owner(auth.uid()))
WITH CHECK (public.is_owner(auth.uid()));


-- ========================================================================
-- TABLE: products
-- Stores the bakery's cake catalog.
-- Public customers can read products; only owners can mutate.
-- ========================================================================
CREATE TABLE IF NOT EXISTS public.products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    name_bn TEXT,
    description TEXT NOT NULL,
    description_bn TEXT,
    price NUMERIC NOT NULL CHECK (price >= 0),
    category TEXT NOT NULL CHECK (category IN ('birthday', 'chocolate', 'wedding', 'cupcakes', 'anniversary', 'custom')),
    image_url TEXT NOT NULL,
    is_available BOOLEAN NOT NULL DEFAULT true,
    weight_options TEXT[] DEFAULT ARRAY['1 kg (6-8 servings)', '1.5 kg (10-12 servings)', '2 kg (16-18 servings)'],
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- Index on category and availability for fast storefront queries
CREATE INDEX IF NOT EXISTS idx_products_category ON public.products(category);
CREATE INDEX IF NOT EXISTS idx_products_is_available ON public.products(is_available);

-- Enable RLS on products
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

-- RLS: Anyone (anonymous and authenticated) can browse available cakes
CREATE POLICY "Public can view available cakes"
ON public.products
FOR SELECT
TO anon, authenticated
USING (is_available = true OR public.is_owner(auth.uid()));

-- RLS: Only owners can create cakes
CREATE POLICY "Only owners can insert cakes"
ON public.products
FOR INSERT
TO authenticated
WITH CHECK (public.is_owner(auth.uid()));

-- RLS: Only owners can update cake details
CREATE POLICY "Only owners can update cakes"
ON public.products
FOR UPDATE
TO authenticated
USING (public.is_owner(auth.uid()))
WITH CHECK (public.is_owner(auth.uid()));

-- RLS: Only owners can delete cakes
CREATE POLICY "Only owners can delete cakes"
ON public.products
FOR DELETE
TO authenticated
USING (public.is_owner(auth.uid()));


-- ========================================================================
-- TABLE: orders
-- Stores customer cake orders with contact info, custom inscription & items.
-- Customer privacy is strictly protected: customers can INSERT their order,
-- but CANNOT query or view other customers' orders.
-- Only verified owners can review and update orders.
-- ========================================================================
CREATE TABLE IF NOT EXISTS public.orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_name TEXT NOT NULL CHECK (length(trim(customer_name)) > 0),
    customer_phone TEXT NOT NULL CHECK (length(trim(customer_phone)) >= 6),
    delivery_address TEXT NOT NULL CHECK (length(trim(delivery_address)) > 0),
    delivery_date DATE NOT NULL,
    cake_message TEXT,
    items JSONB NOT NULL,
    total_amount NUMERIC NOT NULL CHECK (total_amount >= 0),
    status TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending', 'Confirmed', 'Preparing', 'Out for Delivery', 'Delivered', 'Cancelled')),
    payment_method TEXT NOT NULL DEFAULT 'Cash on Delivery (Pay at Door)',
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- Indexes for order dashboard sorting & filtering
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON public.orders(created_at DESC);

-- Enable RLS on orders
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- RLS: Public can insert their order (checkout form)
CREATE POLICY "Public can submit customer order"
ON public.orders
FOR INSERT
TO anon, authenticated
WITH CHECK (
    length(trim(customer_name)) > 0 AND
    length(trim(customer_phone)) >= 6 AND
    length(trim(delivery_address)) > 0 AND
    total_amount >= 0
);

-- RLS: Only owners can view all customer orders (strictly protects customer PII)
CREATE POLICY "Owners can view customer orders"
ON public.orders
FOR SELECT
TO authenticated
USING (public.is_owner(auth.uid()));

-- RLS: Only owners can update order status
CREATE POLICY "Owners can update order status"
ON public.orders
FOR UPDATE
TO authenticated
USING (public.is_owner(auth.uid()))
WITH CHECK (public.is_owner(auth.uid()));

-- RLS: Only owners can delete orders
CREATE POLICY "Owners can delete orders"
ON public.orders
FOR DELETE
TO authenticated
USING (public.is_owner(auth.uid()));


-- ========================================================================
-- STORAGE BUCKET: cake-images (Optional image upload)
-- Run these statements in Supabase to configure the image bucket
-- ========================================================================
INSERT INTO storage.buckets (id, name, public)
VALUES ('cake-images', 'cake-images', true)
ON CONFLICT (id) DO NOTHING;

-- Public can view cake images
CREATE POLICY "Public can view cake images"
ON storage.objects
FOR SELECT
TO anon, authenticated
USING (bucket_id = 'cake-images');

-- Only verified owners can upload cake images
CREATE POLICY "Owners can upload cake images"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
    bucket_id = 'cake-images' AND
    public.is_owner(auth.uid())
);

-- Only verified owners can delete cake images
CREATE POLICY "Owners can delete cake images"
ON storage.objects
FOR DELETE
TO authenticated
USING (
    bucket_id = 'cake-images' AND
    public.is_owner(auth.uid())
);


-- ========================================================================
-- HOW TO ASSIGN THE OWNER ROLE TO YOUR ACCOUNT:
-- 1. Sign up or log into Supabase Dashboard -> Authentication -> Users.
-- 2. Copy your user's UUID.
-- 3. In the Supabase SQL Editor, run:
--
--    INSERT INTO public.user_roles (user_id, role)
--    VALUES ('PASTE-YOUR-USER-UUID-HERE', 'owner')
--    ON CONFLICT (user_id) DO UPDATE SET role = 'owner';
-- ========================================================================
