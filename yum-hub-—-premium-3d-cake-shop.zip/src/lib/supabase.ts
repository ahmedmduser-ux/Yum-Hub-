import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Order, Product } from '../types';

// Storage keys for custom configured credentials in browser
const LOCAL_STORAGE_URL_KEY = 'yumhub_supabase_url';
const LOCAL_STORAGE_KEY_KEY = 'yumhub_supabase_anon_key';

export function getSupabaseCredentials(): { url: string; anonKey: string } {
  // First check env variables
  const envUrl = import.meta.env.VITE_SUPABASE_URL?.trim();
  const envKey = import.meta.env.VITE_SUPABASE_ANON_KEY?.trim();

  // Then check localStorage override
  let localUrl = '';
  let localKey = '';
  try {
    localUrl = localStorage.getItem(LOCAL_STORAGE_URL_KEY)?.trim() || '';
    localKey = localStorage.getItem(LOCAL_STORAGE_KEY_KEY)?.trim() || '';
  } catch (e) {
    // Local storage may be restricted
  }

  const url = localUrl || envUrl || '';
  const anonKey = localKey || envKey || '';

  return { url, anonKey };
}

export function saveSupabaseCredentials(url: string, anonKey: string): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_URL_KEY, url.trim());
    localStorage.setItem(LOCAL_STORAGE_KEY_KEY, anonKey.trim());
    // Reset client cache
    cachedClient = null;
  } catch (e) {
    console.error('Failed to save Supabase credentials:', e);
  }
}

export function clearCustomSupabaseCredentials(): void {
  try {
    localStorage.removeItem(LOCAL_STORAGE_URL_KEY);
    localStorage.removeItem(LOCAL_STORAGE_KEY_KEY);
    cachedClient = null;
  } catch (e) {
    console.error('Failed to clear Supabase credentials:', e);
  }
}

export function isSupabaseConfigured(): boolean {
  const { url, anonKey } = getSupabaseCredentials();
  return Boolean(
    url &&
    anonKey &&
    !url.includes('your-project-id') &&
    !anonKey.includes('your-anon-or-publishable-key') &&
    url.startsWith('https://')
  );
}

let cachedClient: SupabaseClient | null = null;

export function getSupabase(): SupabaseClient | null {
  if (cachedClient) return cachedClient;

  const { url, anonKey } = getSupabaseCredentials();
  if (!url || !anonKey || !isSupabaseConfigured()) {
    return null;
  }

  try {
    cachedClient = createClient(url, anonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    });
    return cachedClient;
  } catch (error) {
    console.error('Error creating Supabase client:', error);
    return null;
  }
}

/**
 * Check if the current authenticated user has the 'owner' role in user_roles.
 * This is verified against the database with RLS.
 */
export async function verifyUserIsOwner(userId: string): Promise<boolean> {
  const client = getSupabase();
  if (!client || !userId) return false;

  try {
    const { data, error } = await client
      .from('user_roles')
      .select('role')
      .eq('user_id', userId)
      .single();

    if (error || !data) {
      console.warn('Role verification failed or no role found:', error?.message);
      return false;
    }

    return data.role === 'owner';
  } catch (err) {
    console.error('Error verifying owner role:', err);
    return false;
  }
}

/**
 * Insert a customer order into the Supabase orders table.
 * If Supabase is not configured or fails, returns { success: false, error: string }.
 */
export async function submitOrderToSupabase(orderData: {
  customer_name: string;
  customer_phone: string;
  delivery_address: string;
  delivery_date: string;
  cake_message?: string;
  items: unknown;
  total_amount: number;
  status: string;
  payment_method: string;
}): Promise<{ success: boolean; orderId?: string; error?: string }> {
  const client = getSupabase();
  if (!client) {
    return {
      success: false,
      error: 'Supabase database is not configured yet with valid URL & Key. Please check the setup guide or use WhatsApp direct order.',
    };
  }

  try {
    const { data, error } = await client
      .from('orders')
      .insert([orderData])
      .select('id')
      .single();

    if (error) {
      return { success: false, error: error.message };
    }

    return { success: true, orderId: data?.id };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown database error';
    return { success: false, error: message };
  }
}

/**
 * Fetch products from Supabase
 */
export async function fetchProductsFromSupabase(): Promise<{ products: Product[] | null; error?: string }> {
  const client = getSupabase();
  if (!client) return { products: null };

  try {
    const { data, error } = await client
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      return { products: null, error: error.message };
    }

    return { products: (data as Product[]) || [] };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Error querying products';
    return { products: null, error: message };
  }
}

/**
 * Upload an image to Supabase Storage bucket 'cake-images'
 */
export async function uploadCakeImageToSupabase(file: File): Promise<{ url?: string; error?: string }> {
  const client = getSupabase();
  if (!client) {
    return { error: 'Supabase client is not connected' };
  }

  try {
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}.${fileExt}`;
    const filePath = `cakes/${fileName}`;

    const { error: uploadError } = await client.storage
      .from('cake-images')
      .upload(filePath, file, { cacheControl: '3600', upsert: false });

    if (uploadError) {
      return { error: uploadError.message };
    }

    const { data } = client.storage.from('cake-images').getPublicUrl(filePath);
    return { url: data.publicUrl };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Upload failed';
    return { error: message };
  }
}
