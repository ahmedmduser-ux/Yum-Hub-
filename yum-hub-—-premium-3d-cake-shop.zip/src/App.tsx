import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ProductCard } from './components/ProductCard';
import { ProductModal } from './components/ProductModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { AdminPanel } from './components/AdminPanel';
import { Footer } from './components/Footer';
import { INITIAL_PRODUCTS } from './data/initialProducts';
import { Product, CartItem, Language, CakeCategory, ShopSettings } from './types';
import { translations } from './lib/translations';
import { fetchProductsFromSupabase } from './lib/supabase';
import { Search, Sparkles, Heart, Quote, ArrowDown, Check } from 'lucide-react';

export default function App() {
  const [language, setLanguage] = useState<Language>('en');
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [selectedCategory, setSelectedCategory] = useState<CakeCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Cart state
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  
  // Modals
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  // Shop Settings
  const [shopSettings, setShopSettings] = useState<ShopSettings>({
    shop_name: 'YUM HUB',
    whatsapp_number: import.meta.env.VITE_SHOP_WHATSAPP_NUMBER || '8801700000000',
    currency_symbol: '৳',
    currency_code: 'BDT',
    delivery_fee: 120,
    free_delivery_threshold: 3000,
    address: 'Banani Road 11, Block D, Dhaka, Bangladesh',
    phone: '+880 1712 345678',
    email: 'hello@yumhub.com',
  });

  const t = translations[language];

  // Try loading live products from Supabase on start
  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    const res = await fetchProductsFromSupabase();
    if (res.products && res.products.length > 0) {
      setProducts(res.products);
    }
  };

  // Cart operations
  const handleAddToCart = (product: Product, quantity = 1, selectedWeight?: string) => {
    setCart((prev) => {
      const existingIndex = prev.findIndex(
        (item) => item.product.id === product.id && item.selected_weight === selectedWeight
      );
      if (existingIndex > -1) {
        const next = [...prev];
        next[existingIndex].quantity += quantity;
        return next;
      }
      return [...prev, { product, quantity, selected_weight: selectedWeight || product.weight_options?.[0] }];
    });
  };

  const handleUpdateCartQuantity = (index: number, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveCartItem(index);
      return;
    }
    setCart((prev) => {
      const next = [...prev];
      next[index].quantity = newQty;
      return next;
    });
  };

  const handleRemoveCartItem = (index: number) => {
    setCart((prev) => prev.filter((_, i) => i !== index));
  };

  const handleOrderSuccess = () => {
    setCart([]);
  };

  // Smooth scroll helper
  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Filter products by category & search
  const filteredProducts = products.filter((p) => {
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
    const nameToSearch = language === 'bn' && p.name_bn ? p.name_bn : p.name;
    const matchesSearch =
      nameToSearch.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const categoriesList: { id: CakeCategory; label: string }[] = [
    { id: 'all', label: t.cat_all },
    { id: 'birthday', label: t.cat_birthday },
    { id: 'chocolate', label: t.cat_chocolate },
    { id: 'wedding', label: t.cat_wedding },
    { id: 'cupcakes', label: t.cat_cupcakes },
    { id: 'anniversary', label: t.cat_anniversary },
    { id: 'custom', label: t.cat_custom },
  ];

  return (
    <div className="min-h-screen bg-[#FAF7F2] text-[#2D1810] flex flex-col font-sans">
      
      {/* Top Bar Navigation adhering to 3-zone contract */}
      <Navbar
        language={language}
        onLanguageChange={setLanguage}
        cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onNavigateSection={scrollToSection}
      />

      {/* Hero Section with 3D interactive centerpiece card */}
      <Hero
        language={language}
        onExploreClick={() => scrollToSection('catalog')}
        onCustomOrderClick={() => {
          setSelectedCategory('custom');
          scrollToSection('catalog');
        }}
      />

      {/* Catalog & Filter Section */}
      <section id="catalog" className="py-12 sm:py-20 border-t border-[#EBDDD8] bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Section Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-[#8D4B55] mb-2">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Couture Patisserie</span>
              </div>
              <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#2D1810]">
                {t.catalog_title}
              </h2>
              <p className="text-sm text-[#7A5850] max-w-2xl mt-2 font-light">
                {t.catalog_subtitle}
              </p>
            </div>

            {/* Search Input */}
            <div className="relative w-full md:w-72">
              <Search className="w-4 h-4 absolute left-3.5 top-3 text-[#8C6D65]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.search_placeholder}
                className="w-full pl-10 pr-4 py-2 text-xs rounded-lg border border-[#EADED9] focus:outline-none focus:ring-1 focus:ring-[#8D4B55] bg-[#FAF7F2] text-[#2D1810] placeholder:text-[#A07066]"
              />
            </div>
          </div>

          {/* Interactive Category Segmented Controls (Buttons with click handlers) */}
          <div id="categories" className="flex items-center gap-1.5 p-1.5 bg-[#FAF7F2] border border-[#EADED9] rounded-xl overflow-x-auto mb-8 scrollbar-none">
            {categoriesList.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  selectedCategory === cat.id
                    ? 'bg-[#2D1810] text-white shadow-sm'
                    : 'text-[#6B534E] hover:text-[#2D1810] hover:bg-white/60'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Product Grid: 3-column desktop / 2-column tablet / 1-column mobile */}
          {filteredProducts.length === 0 ? (
            <div className="py-20 text-center bg-[#FAF7F2] rounded-2xl border border-[#EBDDD8] p-8">
              <p className="text-base font-semibold text-[#2D1810]">{t.no_products}</p>
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setSearchQuery('');
                }}
                className="mt-3 text-xs font-semibold text-[#8D4B55] underline cursor-pointer"
              >
                Reset filters and show all cakes
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  language={language}
                  onQuickView={(p) => setSelectedProduct(p)}
                  onAddToCart={(p) => handleAddToCart(p)}
                />
              ))}
            </div>
          )}

        </div>
      </section>

      {/* Story & Craftsmanship Section */}
      <section id="story" className="py-16 sm:py-24 bg-[#FAF7F2] border-t border-[#EBDDD8]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Story Visual Presentation */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-2xl overflow-hidden border border-[#EBDDD8] luxury-shadow">
                <img
                  src="/src/assets/images/cake_caramel_anniversary_1792666088507.jpg"
                  alt="YUM HUB Craftsmanship"
                  referrerPolicy="no-referrer"
                  className="w-full aspect-[4/3] object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-4 bg-white p-4 rounded-xl border border-[#EBDDD8] shadow-lg hidden sm:block max-w-[220px]">
                <div className="font-display text-sm font-bold text-[#2D1810]">
                  Pure Dairy Butter
                </div>
                <p className="text-[11px] text-[#7A5850] mt-0.5">
                  Slow-simmered caramel, pure extracts, zero artificial emulsifiers.
                </p>
              </div>
            </div>

            {/* Story Text */}
            <div id="custom" className="lg:col-span-7 space-y-5">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#8D4B55]">
                {t.story_badge}
              </span>
              <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#2D1810] [text-wrap:balance]">
                {t.story_title}
              </h2>
              <p className="text-sm sm:text-base text-[#5D4037] leading-relaxed font-light">
                {t.story_p1}
              </p>
              <p className="text-sm sm:text-base text-[#5D4037] leading-relaxed font-light">
                {t.story_p2}
              </p>
              
              <div className="pt-2 flex flex-wrap gap-4">
                <button
                  onClick={() => setIsCartOpen(true)}
                  className="px-6 py-3 bg-[#2D1810] hover:bg-[#3E2723] text-white rounded-lg text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer"
                >
                  View Your Bag
                </button>
                <a
                  href={`https://wa.me/${shopSettings.whatsapp_number.replace(/\D/g, '')}?text=${encodeURIComponent('Hello YUM HUB, I would like to inquire about a custom bespoke cake for an upcoming event.')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-3 bg-[#FFF5F3] hover:bg-[#FEECEB] text-[#2D1810] border border-[#EBDDD8] rounded-lg text-xs font-semibold uppercase tracking-wider transition-colors"
                >
                  Bespoke Consultation
                </a>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Attributable Testimonials Section */}
      <section className="py-14 sm:py-20 bg-white border-t border-[#EBDDD8]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-xl mx-auto mb-10">
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#2D1810]">
              {t.testimonial_title}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Testimonial 1 */}
            <div className="bg-[#FAF7F2] p-6 rounded-2xl border border-[#EBDDD8] space-y-4">
              <Quote className="w-6 h-6 text-[#8D4B55]/60" />
              <p className="text-sm text-[#3E2723] italic leading-relaxed">
                "{t.testimonial_1_quote}"
              </p>
              <div className="pt-2 border-t border-[#EBDDD8] flex items-center justify-between text-xs font-semibold text-[#2D1810]">
                <span>{t.testimonial_1_author}</span>
                <span className="text-[#8D4B55]">Belgian Dark Truffle</span>
              </div>
            </div>

            {/* Testimonial 2 */}
            <div className="bg-[#FAF7F2] p-6 rounded-2xl border border-[#EBDDD8] space-y-4">
              <Quote className="w-6 h-6 text-[#8D4B55]/60" />
              <p className="text-sm text-[#3E2723] italic leading-relaxed">
                "{t.testimonial_2_quote}"
              </p>
              <div className="pt-2 border-t border-[#EBDDD8] flex items-center justify-between text-xs font-semibold text-[#2D1810]">
                <span>{t.testimonial_2_author}</span>
                <span className="text-[#8D4B55]">Custom Celebration</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer
        language={language}
        shopSettings={shopSettings}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onNavigateSection={scrollToSection}
      />

      {/* Product Detail Modal */}
      <ProductModal
        product={selectedProduct}
        language={language}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={(p, qty, weight) => handleAddToCart(p, qty, weight)}
      />

      {/* Pastry Bag Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        language={language}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
      />

      {/* Order & Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cart={cart}
        language={language}
        shopSettings={shopSettings}
        onOrderSuccess={handleOrderSuccess}
      />

      {/* Private Owner-Only Admin Panel */}
      <AdminPanel
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        language={language}
        products={products}
        onRefreshProducts={loadProducts}
        shopSettings={shopSettings}
        onUpdateShopSettings={setShopSettings}
      />

    </div>
  );
}
