export type Language = 'en' | 'bn';

export type CakeCategory = 
  | 'all'
  | 'birthday'
  | 'chocolate'
  | 'wedding'
  | 'cupcakes'
  | 'anniversary'
  | 'custom';

export interface Product {
  id: string;
  name: string;
  name_bn?: string;
  description: string;
  description_bn?: string;
  price: number;
  category: CakeCategory;
  image_url: string;
  is_available: boolean;
  weight_options?: string[];
  created_at?: string;
  updated_at?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selected_weight?: string;
  custom_message?: string;
}

export type OrderStatus = 
  | 'Pending'
  | 'Confirmed'
  | 'Preparing'
  | 'Out for Delivery'
  | 'Delivered'
  | 'Cancelled';

export interface OrderItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  weight?: string;
}

export interface Order {
  id: string;
  customer_name: string;
  customer_phone: string;
  delivery_address: string;
  delivery_date: string;
  cake_message?: string;
  items: OrderItem[];
  total_amount: number;
  status: OrderStatus;
  payment_method: string;
  notes?: string;
  created_at: string;
}

export interface UserRoleRecord {
  user_id: string;
  role: 'owner' | 'admin' | 'customer';
  created_at?: string;
}

export interface ShopSettings {
  shop_name: string;
  whatsapp_number: string;
  currency_symbol: string;
  currency_code: string;
  delivery_fee: number;
  free_delivery_threshold: number;
  address: string;
  phone: string;
  email: string;
}
