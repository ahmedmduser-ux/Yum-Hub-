import React, { useState } from 'react';
import { X, Send, CheckCircle2, AlertTriangle, ShieldCheck, Calendar, Phone, MapPin, User, FileText } from 'lucide-react';
import confetti from 'canvas-confetti';
import { CartItem, Language, ShopSettings } from '../types';
import { translations } from '../lib/translations';
import { submitOrderToSupabase, isSupabaseConfigured } from '../lib/supabase';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  language: Language;
  shopSettings: ShopSettings;
  onOrderSuccess: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cart,
  language,
  shopSettings,
  onOrderSuccess,
}) => {
  if (!isOpen) return null;

  const t = translations[language];

  // Tomorrow's date formatted as YYYY-MM-DD for default delivery date
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];

  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [deliveryDate, setDeliveryDate] = useState(tomorrowStr);
  const [cakeMessage, setCakeMessage] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [dbOrderSuccess, setDbOrderSuccess] = useState<{ id: string } | null>(null);

  const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const deliveryFee = subtotal > shopSettings.free_delivery_threshold ? 0 : shopSettings.delivery_fee;
  const total = subtotal + deliveryFee;

  // Form validation
  const validateForm = (): boolean => {
    if (!customerName.trim() || !customerPhone.trim() || !deliveryAddress.trim() || !deliveryDate) {
      setErrorMsg(t.order_validation_error);
      return false;
    }
    if (customerPhone.trim().length < 6) {
      setErrorMsg('Please enter a valid phone number (at least 6 digits).');
      return false;
    }
    setErrorMsg(null);
    return true;
  };

  // Generate formatted WhatsApp message URL
  const generateWhatsAppUrl = (orderId?: string): string => {
    const lines = [
      t.wa_greeting,
      '',
      ...(orderId ? [`*Order Reference:* #${orderId}`] : []),
      `*${t.wa_customer_name}* ${customerName.trim()}`,
      `*${t.wa_customer_phone}* ${customerPhone.trim()}`,
      `*${t.wa_delivery_addr}* ${deliveryAddress.trim()}`,
      `*${t.wa_delivery_date}* ${deliveryDate}`,
      ...(cakeMessage.trim() ? [`*${t.wa_cake_msg}* "${cakeMessage.trim()}"`] : []),
      '',
      `*${t.wa_items_header}*`,
      ...cart.map(
        (item) =>
          `• ${item.product.name} (${item.selected_weight || 'Standard'}) x ${item.quantity} = ৳${(
            item.product.price * item.quantity
          ).toLocaleString()}`
      ),
      '',
      `*Subtotal:* ৳${subtotal.toLocaleString()}`,
      `*Delivery:* ${deliveryFee === 0 ? 'Free' : `৳${deliveryFee}`}`,
      `*${t.wa_total}* ৳${total.toLocaleString()}`,
      `*Payment:* Cash on Delivery`,
    ];

    const encodedText = encodeURIComponent(lines.join('\n'));
    // Clean phone number (remove + or spaces)
    const cleanNumber = shopSettings.whatsapp_number.replace(/\D/g, '');
    return `https://wa.me/${cleanNumber}?text=${encodedText}`;
  };

  // Submit to Supabase Database
  const handleSaveToDatabase = async () => {
    if (!validateForm()) return;

    setIsSubmitting(true);
    setErrorMsg(null);

    const orderPayload = {
      customer_name: customerName.trim(),
      customer_phone: customerPhone.trim(),
      delivery_address: deliveryAddress.trim(),
      delivery_date: deliveryDate,
      cake_message: cakeMessage.trim() || undefined,
      items: cart.map((c) => ({
        id: c.product.id,
        name: c.product.name,
        price: c.product.price,
        quantity: c.quantity,
        weight: c.selected_weight,
      })),
      total_amount: total,
      status: 'Pending',
      payment_method: 'Cash on Delivery (Pay at Door)',
    };

    const res = await submitOrderToSupabase(orderPayload);
    setIsSubmitting(false);

    if (res.success && res.orderId) {
      // Fire celebratory confetti!
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#FDE2E4', '#8D4B55', '#2D1810', '#F5EDE9'],
        });
      } catch (e) {
        // Confetti fallback
      }
      setDbOrderSuccess({ id: res.orderId });
      onOrderSuccess();
    } else {
      // NEVER pretend order was saved if database request failed.
      setErrorMsg(
        res.error ||
          'Failed to save order to the Supabase database. You can still send your order directly to our official WhatsApp below.'
      );
    }
  };

  // Direct WhatsApp Order
  const handleDirectWhatsApp = () => {
    if (!validateForm()) return;
    const url = generateWhatsAppUrl();
    window.open(url, '_blank', 'noopener,noreferrer');
    onOrderSuccess();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#2D1810]/60 backdrop-blur-sm overflow-y-auto">
      <div 
        className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-[#EBDDD8] overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-[#EBDDD8] flex items-center justify-between bg-[#FAF7F2]">
          <div>
            <h2 className="font-display text-xl font-bold text-[#2D1810]">
              {dbOrderSuccess ? t.success_title : t.checkout_title}
            </h2>
            <p className="text-xs text-[#7A5850] mt-0.5">
              {dbOrderSuccess ? t.success_msg : t.checkout_subtitle}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#5D4037] hover:text-[#2D1810] hover:bg-[#FAF7F2] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {dbOrderSuccess ? (
            /* Success State */
            <div className="text-center py-6 space-y-5">
              <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-9 h-9" />
              </div>

              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-[#8D4B55]">
                  {t.order_id_label}
                </span>
                <p className="font-mono text-sm font-bold text-[#2D1810] mt-0.5 break-all">
                  #{dbOrderSuccess.id}
                </p>
              </div>

              <div className="p-4 bg-[#FAF7F2] rounded-xl border border-[#EBDDD8] text-left text-xs space-y-1.5 text-[#5D4037]">
                <div className="flex justify-between">
                  <span className="font-medium">Customer:</span>
                  <span className="font-semibold text-[#2D1810]">{customerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Phone:</span>
                  <span className="font-semibold text-[#2D1810]">{customerPhone}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Delivery Date:</span>
                  <span className="font-semibold text-[#2D1810]">{deliveryDate}</span>
                </div>
                <div className="flex justify-between pt-1 border-t border-[#EBDDD8]">
                  <span className="font-bold text-[#2D1810]">Total (Cash on Delivery):</span>
                  <span className="font-mono font-bold text-[#2D1810]">৳ {total.toLocaleString()}</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <a
                  href={generateWhatsAppUrl(dbOrderSuccess.id)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-4 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-lg text-xs font-semibold uppercase tracking-wider shadow transition-colors cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>{t.success_whatsapp_button}</span>
                </a>
                <button
                  onClick={onClose}
                  className="px-6 py-3 border border-[#EBDDD8] bg-white text-[#2D1810] hover:bg-[#FAF7F2] rounded-lg text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer"
                >
                  {t.success_close}
                </button>
              </div>
            </div>
          ) : (
            /* Order Form */
            <div className="space-y-4">
              
              {/* Error Callout */}
              {errorMsg && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-start gap-2.5">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="font-medium">{errorMsg}</p>
                    <p className="text-[11px] text-rose-700">
                      Tip: You can use the green "Order via WhatsApp Directly" button below to place your order right away!
                    </p>
                  </div>
                </div>
              )}

              {/* Customer Name */}
              <div>
                <label className="flex items-center gap-1.5 text-xs font-semibold text-[#2D1810] mb-1">
                  <User className="w-3.5 h-3.5 text-[#8D4B55]" />
                  <span>{t.input_name}</span>
                </label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder={t.input_name_placeholder}
                  className="w-full px-3.5 py-2.5 text-xs rounded-lg border border-[#EADED9] focus:outline-none focus:ring-1 focus:ring-[#8D4B55] bg-white text-[#2D1810]"
                />
              </div>

              {/* Phone & Date */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="flex items-center gap-1.5 text-xs font-semibold text-[#2D1810] mb-1">
                    <Phone className="w-3.5 h-3.5 text-[#8D4B55]" />
                    <span>{t.input_phone}</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder={t.input_phone_placeholder}
                    className="w-full px-3.5 py-2.5 text-xs rounded-lg border border-[#EADED9] focus:outline-none focus:ring-1 focus:ring-[#8D4B55] bg-white text-[#2D1810]"
                  />
                </div>

                <div>
                  <label className="flex items-center gap-1.5 text-xs font-semibold text-[#2D1810] mb-1">
                    <Calendar className="w-3.5 h-3.5 text-[#8D4B55]" />
                    <span>{t.input_date}</span>
                  </label>
                  <input
                    type="date"
                    required
                    min={tomorrowStr}
                    value={deliveryDate}
                    onChange={(e) => setDeliveryDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs rounded-lg border border-[#EADED9] focus:outline-none focus:ring-1 focus:ring-[#8D4B55] bg-white text-[#2D1810]"
                  />
                </div>
              </div>

              {/* Delivery Address */}
              <div>
                <label className="flex items-center gap-1.5 text-xs font-semibold text-[#2D1810] mb-1">
                  <MapPin className="w-3.5 h-3.5 text-[#8D4B55]" />
                  <span>{t.input_address}</span>
                </label>
                <textarea
                  rows={2}
                  required
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  placeholder={t.input_address_placeholder}
                  className="w-full px-3.5 py-2.5 text-xs rounded-lg border border-[#EADED9] focus:outline-none focus:ring-1 focus:ring-[#8D4B55] bg-white text-[#2D1810] resize-none"
                />
              </div>

              {/* Custom Cake Message / Inscription */}
              <div>
                <label className="flex items-center gap-1.5 text-xs font-semibold text-[#2D1810] mb-1">
                  <FileText className="w-3.5 h-3.5 text-[#8D4B55]" />
                  <span>{t.input_message}</span>
                </label>
                <input
                  type="text"
                  value={cakeMessage}
                  onChange={(e) => setCakeMessage(e.target.value)}
                  placeholder={t.input_message_placeholder}
                  className="w-full px-3.5 py-2.5 text-xs rounded-lg border border-[#EADED9] focus:outline-none focus:ring-1 focus:ring-[#8D4B55] bg-white text-[#2D1810]"
                />
              </div>

              {/* Payment note & total */}
              <div className="pt-2 border-t border-[#F2E8E4] space-y-2">
                <div className="p-3 bg-[#FFF5F3] rounded-lg border border-[#FDE2E4] text-xs">
                  <div className="font-semibold text-[#2D1810] flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#8D4B55]" />
                    <span>{t.payment_cod}</span>
                  </div>
                  <p className="text-[11px] text-[#7A5850] mt-0.5 leading-relaxed">
                    {t.payment_online_note}
                  </p>
                </div>

                <div className="flex justify-between items-baseline pt-1">
                  <span className="text-xs font-semibold text-[#5D4037]">Total Order Payable:</span>
                  <span className="font-mono text-lg font-bold tabular-nums text-[#2D1810]">
                    ৳ {total.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 space-y-2">
                {/* Save to Supabase Order Button */}
                <button
                  type="button"
                  onClick={handleSaveToDatabase}
                  disabled={isSubmitting}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-[#2D1810] hover:bg-[#3E2723] text-white rounded-lg text-xs font-semibold uppercase tracking-wider shadow transition-all cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>{isSubmitting ? t.order_submitting : t.order_place_db}</span>
                </button>

                {/* Direct WhatsApp Button */}
                <button
                  type="button"
                  onClick={handleDirectWhatsApp}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-lg text-xs font-semibold uppercase tracking-wider shadow transition-all cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>{t.order_place_whatsapp}</span>
                </button>
              </div>

            </div>
          )}
        </div>

      </div>
    </div>
  );
};
