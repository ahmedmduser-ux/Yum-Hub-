import React, { useState } from 'react';
import { ShoppingBag, Globe, Menu, X, ShieldCheck } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../lib/translations';

interface NavbarProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenAdmin: () => void;
  onNavigateSection: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  language,
  onLanguageChange,
  cartCount,
  onOpenCart,
  onOpenAdmin,
  onNavigateSection,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const t = translations[language];

  const handleNavClick = (sectionId: string) => {
    setMobileMenuOpen(false);
    onNavigateSection(sectionId);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-[#EADED9] bg-[#FAF7F2]/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-20">
          
          {/* Zone 1: Single text element Brand Zone */}
          <button
            onClick={() => handleNavClick('hero')}
            className="text-left group cursor-pointer focus:outline-none"
          >
            <span className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#2D1810] group-hover:text-[#8D4B55] transition-colors whitespace-nowrap shrink-0">
              YUM HUB
            </span>
          </button>

          {/* Zone 2: 4-5 concise single-line text links */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-[#5D4037]">
            <button
              onClick={() => handleNavClick('catalog')}
              className="hover:text-[#2D1810] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {t.nav_collection}
            </button>
            <button
              onClick={() => handleNavClick('categories')}
              className="hover:text-[#2D1810] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {t.nav_categories}
            </button>
            <button
              onClick={() => handleNavClick('custom')}
              className="hover:text-[#2D1810] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {t.nav_custom}
            </button>
            <button
              onClick={() => handleNavClick('story')}
              className="hover:text-[#2D1810] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {t.nav_story}
            </button>
            <button
              onClick={onOpenAdmin}
              className="hover:text-[#2D1810] text-[#7A5850] transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5"
            >
              <ShieldCheck className="w-4 h-4 text-[#8D4B55]" />
              {t.nav_admin}
            </button>
          </nav>

          {/* Zone 3: Primary Action & Bag Button */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Language Switcher */}
            <button
              onClick={() => onLanguageChange(language === 'en' ? 'bn' : 'en')}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#5D4037] hover:text-[#2D1810] bg-[#F5ECE8] hover:bg-[#EBDDD8] rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0"
              title="Toggle Language (English / বাংলা)"
            >
              <Globe className="w-3.5 h-3.5 text-[#8D4B55]" />
              <span>{language === 'en' ? 'বাংলা' : 'EN'}</span>
            </button>

            {/* Shopping Bag Button */}
            <button
              onClick={onOpenCart}
              className="relative flex items-center gap-2 px-4 py-2 text-xs font-semibold tracking-wide uppercase text-white bg-[#2D1810] hover:bg-[#3E2723] rounded-lg transition-all shadow-sm hover:shadow-md cursor-pointer whitespace-nowrap shrink-0"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">{t.nav_cart}</span>
              <span className="inline-flex items-center justify-center min-w-5 h-5 px-1.5 text-[11px] font-bold text-[#2D1810] bg-[#FDE2E4] rounded-full tabular-nums">
                {cartCount}
              </span>
            </button>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-[#2D1810] hover:bg-[#F5ECE8] rounded-lg transition-colors cursor-pointer"
              aria-label="Open Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-[#EADED9] bg-[#FAF7F2] px-6 py-6 space-y-4 shadow-lg animate-in fade-in duration-200">
          <button
            onClick={() => handleNavClick('catalog')}
            className="block w-full text-left py-2 text-base font-medium text-[#2D1810] hover:text-[#8D4B55]"
          >
            {t.nav_collection}
          </button>
          <button
            onClick={() => handleNavClick('categories')}
            className="block w-full text-left py-2 text-base font-medium text-[#2D1810] hover:text-[#8D4B55]"
          >
            {t.nav_categories}
          </button>
          <button
            onClick={() => handleNavClick('custom')}
            className="block w-full text-left py-2 text-base font-medium text-[#2D1810] hover:text-[#8D4B55]"
          >
            {t.nav_custom}
          </button>
          <button
            onClick={() => handleNavClick('story')}
            className="block w-full text-left py-2 text-base font-medium text-[#2D1810] hover:text-[#8D4B55]"
          >
            {t.nav_story}
          </button>
          <div className="pt-3 border-t border-[#EADED9] flex items-center justify-between">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAdmin();
              }}
              className="flex items-center gap-2 text-sm font-semibold text-[#8D4B55]"
            >
              <ShieldCheck className="w-4 h-4" />
              {t.nav_admin}
            </button>
            <button
              onClick={() => onLanguageChange(language === 'en' ? 'bn' : 'en')}
              className="text-xs font-semibold text-[#5D4037] underline"
            >
              Switch to {language === 'en' ? 'বাংলা' : 'English'}
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
