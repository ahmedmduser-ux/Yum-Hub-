import React, { useState } from 'react';
import { ShoppingBag, Eye, Cake, Check } from 'lucide-react';
import { Product, Language } from '../types';
import { translations } from '../lib/translations';

interface ProductCardProps {
  product: Product;
  language: Language;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  language,
  onQuickView,
  onAddToCart,
}) => {
  const [imageError, setImageError] = useState(false);
  const [addedAnim, setAddedAnim] = useState(false);
  const [cardTilt, setCardTilt] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const t = translations[language];

  const displayName = language === 'bn' && product.name_bn ? product.name_bn : product.name;
  const displayDesc = language === 'bn' && product.description_bn ? product.description_bn : product.description;

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = ((y - centerY) / centerY) * -6;
    const rotateY = ((x - centerX) / centerX) * 6;
    setCardTilt({ x: rotateX, y: rotateY });
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setCardTilt({ x: 0, y: 0 });
  };

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!product.is_available) return;
    onAddToCart(product);
    setAddedAnim(true);
    setTimeout(() => setAddedAnim(false), 1200);
  };

  return (
    <div
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={handleMouseLeave}
      style={{
        transform: `rotateX(${cardTilt.x}deg) rotateY(${cardTilt.y}deg)`,
        transition: isHovered ? 'transform 0.12s ease-out' : 'transform 0.4s ease-out',
      }}
      className="group relative flex flex-col rounded-xl bg-white p-3 border border-[#EBDDD8] luxury-shadow hover:luxury-shadow-hover transition-all duration-300 transform-style-3d"
    >
      {/* Product Image Slot (65-75% height) */}
      <div 
        onClick={() => onQuickView(product)}
        className="relative aspect-[4/3] w-full rounded-lg overflow-hidden bg-[#FAF7F2] cursor-pointer"
      >
        {!imageError ? (
          <img
            src={product.image_url}
            alt={displayName}
            referrerPolicy="no-referrer"
            onError={() => setImageError(true)}
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
          />
        ) : (
          /* Graceful CSS fallback container if image fails */
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-[#FFF5F3] to-[#FDE2E4] p-4 text-center">
            <Cake className="w-10 h-10 text-[#8D4B55] mb-2 stroke-[1.5]" />
            <span className="text-xs font-semibold text-[#5D4037] line-clamp-1">{displayName}</span>
          </div>
        )}

        {/* Subtle Stock indicator badge if sold out */}
        {!product.is_available && (
          <div className="absolute inset-0 bg-[#2D1810]/60 backdrop-blur-[2px] flex items-center justify-center">
            <span className="text-xs font-semibold uppercase tracking-wider text-white bg-[#2D1810] px-3 py-1 rounded">
              {t.out_of_stock}
            </span>
          </div>
        )}

        {/* Quick View overlay button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onQuickView(product);
          }}
          className="absolute bottom-2.5 right-2.5 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-white/90 hover:bg-white text-[#2D1810] p-2 rounded-md shadow-sm cursor-pointer"
          title={t.view_details}
          aria-label={t.view_details}
        >
          <Eye className="w-4 h-4" />
        </button>
      </div>

      {/* Card Content & Clean Unboxed Metadata */}
      <div className="flex flex-col flex-1 pt-3.5 pb-1 px-1">
        
        {/* Unboxed category metadata with dot separator */}
        <div className="flex items-center gap-1.5 text-xs text-[#7A5850] font-medium uppercase tracking-wider mb-1.5">
          <span>{product.category}</span>
          {product.weight_options && product.weight_options[0] && (
            <>
              <span aria-hidden="true">·</span>
              <span className="text-[#8D4B55] normal-case">{product.weight_options[0].split(' ')[0]}</span>
            </>
          )}
        </div>

        {/* Cake Title */}
        <h3
          onClick={() => onQuickView(product)}
          className="font-display text-base sm:text-lg font-bold text-[#2D1810] group-hover:text-[#8D4B55] transition-colors line-clamp-1 cursor-pointer"
        >
          {displayName}
        </h3>

        {/* Brief description */}
        <p className="text-xs text-[#6B534E] line-clamp-2 mt-1 leading-relaxed font-light">
          {displayDesc}
        </p>

        {/* Price Baseline and Action Row */}
        <div className="mt-auto pt-4 flex items-center justify-between border-t border-[#F2E8E4]">
          <div className="flex flex-col">
            <span className="text-[11px] text-[#8C6D65] uppercase tracking-wider font-medium">Price</span>
            <span className="text-base font-bold font-mono tabular-nums text-[#2D1810]">
              ৳ {product.price.toLocaleString()}
            </span>
          </div>

          <button
            onClick={handleAdd}
            disabled={!product.is_available}
            className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              !product.is_available
                ? 'bg-[#EBDDD8] text-[#8C6D65] cursor-not-allowed'
                : addedAnim
                ? 'bg-[#15803D] text-white'
                : 'bg-[#2D1810] hover:bg-[#3E2723] text-white shadow-sm hover:shadow'
            }`}
          >
            {addedAnim ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Added</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>{t.add_to_bag}</span>
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
};
