import React from 'react';
import { X, Trash2, ArrowRight, ShoppingBag, ShieldCheck } from 'lucide-react';
import { CartItem, Language } from '../types';
import { translations } from '../lib/translations';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  language: Language;
  onUpdateQuantity: (index: number, newQty: number) => void;
  onRemoveItem: (index: number) => void;
  onCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  language,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
}) => {
  if (!isOpen) return null;

  const t = translations[language];

  const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const deliveryFee = subtotal > 3000 ? 0 : (subtotal > 0 ? 120 : 0);
  const total = subtotal + deliveryFee;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-[#2D1810]/50 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#FAF7F2] border-l border-[#EBDDD8] shadow-2xl flex flex-col">
          
          {/* Header */}
          <div className="p-6 border-b border-[#EBDDD8] flex items-center justify-between bg-white">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#8D4B55]" />
              <h2 className="font-display text-xl font-bold text-[#2D1810]">
                {t.cart_title}
              </h2>
              <span className="text-xs text-[#8C6D65] font-mono tabular-nums">
                ({cart.reduce((sum, item) => sum + item.quantity, 0)})
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-[#5D4037] hover:text-[#2D1810] hover:bg-[#FAF7F2] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12">
                <div className="w-16 h-16 rounded-full bg-[#FFF5F3] flex items-center justify-center text-[#8D4B55] mb-4">
                  <ShoppingBag className="w-8 h-8 stroke-[1.5]" />
                </div>
                <h3 className="font-display text-lg font-bold text-[#2D1810]">
                  {t.cart_empty}
                </h3>
                <p className="text-xs text-[#7A5850] max-w-xs mt-1 leading-relaxed">
                  {t.cart_empty_subtext}
                </p>
                <button
                  onClick={onClose}
                  className="mt-6 px-5 py-2.5 bg-[#2D1810] text-white rounded-lg text-xs font-semibold tracking-wide uppercase hover:bg-[#3E2723] transition-colors cursor-pointer"
                >
                  {t.cart_continue}
                </button>
              </div>
            ) : (
              cart.map((item, index) => {
                const displayName = language === 'bn' && item.product.name_bn ? item.product.name_bn : item.product.name;
                return (
                  <div
                    key={`${item.product.id}-${index}`}
                    className="flex gap-4 p-3 bg-white rounded-xl border border-[#EBDDD8] shadow-sm"
                  >
                    {/* Thumbnail */}
                    <div className="w-20 h-20 rounded-lg overflow-hidden bg-[#FAF7F2] shrink-0">
                      <img
                        src={item.product.image_url}
                        alt={displayName}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Details */}
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start gap-2">
                          <h4 className="font-display text-sm font-bold text-[#2D1810] line-clamp-1">
                            {displayName}
                          </h4>
                          <button
                            onClick={() => onRemoveItem(index)}
                            className="text-[#A07066] hover:text-[#DC2626] transition-colors p-0.5 cursor-pointer"
                            title={t.cart_remove}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        {item.selected_weight && (
                          <div className="text-[11px] text-[#8C6D65] mt-0.5">
                            {item.selected_weight}
                          </div>
                        )}
                      </div>

                      {/* Quantity Stepper & Price */}
                      <div className="flex items-center justify-between pt-2">
                        <div className="flex items-center border border-[#EADED9] rounded-md bg-[#FAF7F2]">
                          <button
                            onClick={() => onUpdateQuantity(index, item.quantity - 1)}
                            className="w-6 h-6 flex items-center justify-center text-xs font-bold text-[#2D1810] hover:bg-[#EBDDD8] transition-colors cursor-pointer"
                          >
                            -
                          </button>
                          <span className="w-7 text-center font-mono text-xs font-semibold tabular-nums text-[#2D1810]">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(index, item.quantity + 1)}
                            className="w-6 h-6 flex items-center justify-center text-xs font-bold text-[#2D1810] hover:bg-[#EBDDD8] transition-colors cursor-pointer"
                          >
                            +
                          </button>
                        </div>

                        <span className="text-sm font-bold font-mono tabular-nums text-[#2D1810]">
                          ৳ {(item.product.price * item.quantity).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer Summary */}
          {cart.length > 0 && (
            <div className="p-6 border-t border-[#EBDDD8] bg-white space-y-3">
              <div className="space-y-1.5 text-xs text-[#5D4037]">
                <div className="flex justify-between">
                  <span>{t.cart_subtotal}</span>
                  <span className="font-mono font-medium tabular-nums text-[#2D1810]">
                    ৳ {subtotal.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span>{t.cart_delivery}</span>
                  <span className="font-mono tabular-nums">
                    {deliveryFee === 0 ? (
                      <span className="text-green-700 font-semibold">{t.cart_delivery_free}</span>
                    ) : (
                      `৳ ${deliveryFee}`
                    )}
                  </span>
                </div>
              </div>

              <div className="pt-2 border-t border-[#F2E8E4] flex justify-between items-baseline">
                <span className="font-bold text-[#2D1810] text-sm">{t.cart_total}</span>
                <span className="font-mono text-xl font-bold tabular-nums text-[#2D1810]">
                  ৳ {total.toLocaleString()}
                </span>
              </div>

              <button
                onClick={onCheckout}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-[#2D1810] hover:bg-[#3E2723] text-white rounded-lg text-xs font-semibold uppercase tracking-wider shadow-md hover:shadow-lg transition-all cursor-pointer"
              >
                <span>{t.cart_checkout}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-1.5 text-[11px] text-[#8C6D65] pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-[#8D4B55]" />
                <span>Cash on Delivery & Direct WhatsApp Confirmation</span>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
