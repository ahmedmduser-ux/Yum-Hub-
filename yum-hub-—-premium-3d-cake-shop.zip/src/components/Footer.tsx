import React from 'react';
import { Heart, ShieldCheck, Phone, MapPin, Clock } from 'lucide-react';
import { Language, ShopSettings } from '../types';
import { translations } from '../lib/translations';

interface FooterProps {
  language: Language;
  shopSettings: ShopSettings;
  onOpenAdmin: () => void;
  onNavigateSection: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({
  language,
  shopSettings,
  onOpenAdmin,
  onNavigateSection,
}) => {
  const t = translations[language];

  return (
    <footer className="border-t border-[#EBDDD8] bg-[#FAF7F2] text-[#5D4037]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          
          {/* Brand & Mission */}
          <div className="md:col-span-1 space-y-3">
            <span className="font-display text-2xl font-bold tracking-tight text-[#2D1810]">
              {t.brand}
            </span>
            <p className="text-xs text-[#7A5850] leading-relaxed">
              {t.tagline}
            </p>
            <div className="pt-2 text-xs text-[#8C6D65] space-y-1">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-[#8D4B55]" />
                <span>{t.footer_hours}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#8D4B55]" />
                <span>{shopSettings.address}</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#2D1810]">
              Collections
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigateSection('catalog')}
                  className="hover:text-[#2D1810] transition-colors cursor-pointer"
                >
                  {t.cat_birthday}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('catalog')}
                  className="hover:text-[#2D1810] transition-colors cursor-pointer"
                >
                  {t.cat_chocolate}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('catalog')}
                  className="hover:text-[#2D1810] transition-colors cursor-pointer"
                >
                  {t.cat_wedding}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('catalog')}
                  className="hover:text-[#2D1810] transition-colors cursor-pointer"
                >
                  {t.cat_cupcakes}
                </button>
              </li>
            </ul>
          </div>

          {/* Customer Care & WhatsApp Ordering */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#2D1810]">
              Customer Service
            </h4>
            <div className="space-y-2 text-xs">
              <p className="text-[#7A5850] text-[11px] leading-relaxed">
                Direct customer assistance, custom inscription requests, and delivery coordination.
              </p>
              <a
                href={`https://wa.me/${shopSettings.whatsapp_number.replace(/\D/g, '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 font-semibold text-[#8D4B55] hover:underline"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>WhatsApp: +{shopSettings.whatsapp_number}</span>
              </a>
            </div>
          </div>

          {/* Security & Owner Entry */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#2D1810]">
              Governance
            </h4>
            <div className="space-y-2 text-xs">
              <p className="text-[11px] text-[#7A5850]">
                Protected with Supabase Row Level Security (RLS) and server-side role validation.
              </p>
              <button
                onClick={onOpenAdmin}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#2D1810] bg-[#FFF5F3] hover:bg-[#FEECEB] border border-[#EBDDD8] rounded-md transition-colors cursor-pointer"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-[#8D4B55]" />
                <span>{t.footer_owner_link}</span>
              </button>
            </div>
          </div>

        </div>

        {/* Bottom copyright row */}
        <div className="pt-8 border-t border-[#EBDDD8] flex flex-col sm:flex-row items-center justify-between text-xs text-[#8C6D65] gap-4">
          <p>© {new Date().getFullYear()} {t.footer_rights}</p>
          <div className="flex items-center gap-4 text-[11px]">
            <span>100% Real Photography</span>
            <span>·</span>
            <span>Handmade Fresh Daily</span>
            <span>·</span>
            <span>Bilingual Experience</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
