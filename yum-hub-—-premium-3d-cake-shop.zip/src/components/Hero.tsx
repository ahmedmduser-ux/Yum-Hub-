import React, { useState } from 'react';
import { Sparkles, ArrowRight, Clock, Award, ShieldCheck } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../lib/translations';

interface HeroProps {
  language: Language;
  onExploreClick: () => void;
  onCustomOrderClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  language,
  onExploreClick,
  onCustomOrderClick,
}) => {
  const t = translations[language];

  // 3D Tilt calculation state for the Hero centerpiece card
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [isHovering, setIsHovering] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    // Maximum tilt angles in degrees
    const rotateX = ((y - centerY) / centerY) * -10;
    const rotateY = ((x - centerX) / centerX) * 10;
    setTilt({ x: rotateX, y: rotateY });
  };

  const handleMouseLeave = () => {
    setIsHovering(false);
    setTilt({ x: 0, y: 0 });
  };

  return (
    <section id="hero" className="relative overflow-hidden pt-8 pb-16 sm:pb-24 bg-[#FAF7F2]">
      {/* Background soft ambiance glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[400px] bg-gradient-to-tr from-[#FDE2E4]/40 via-[#FFF1F2]/60 to-transparent blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Copy & CTAs */}
          <div className="lg:col-span-7 space-y-6">
            {/* Unboxed natural editorial kicker without pill badges */}
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-[#8D4B55]">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{t.hero_kicker}</span>
            </div>

            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#2D1810] leading-[1.12] [text-wrap:balance]">
              {t.hero_headline}
            </h1>

            <p className="text-base sm:text-lg text-[#5D4037] leading-relaxed max-w-2xl font-light">
              {t.hero_subhead}
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onExploreClick}
                className="inline-flex items-center justify-center gap-2 px-7 py-3.5 text-sm font-semibold text-white bg-[#2D1810] hover:bg-[#3E2723] rounded-lg transition-all shadow-md hover:shadow-lg cursor-pointer transform hover:-translate-y-0.5 active:translate-y-0"
              >
                <span>{t.hero_cta}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onCustomOrderClick}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-[#2D1810] bg-[#FFF5F3] hover:bg-[#FEECEB] border border-[#E8D5D8] rounded-lg transition-all cursor-pointer"
              >
                <span>{t.hero_secondary_cta}</span>
              </button>
            </div>

            {/* Quiet reassurance markers with typographic separators */}
            <div className="pt-6 border-t border-[#EBDDD8] flex flex-wrap items-center gap-y-2 gap-x-4 text-xs font-medium text-[#7A5850]">
              <span className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-[#8D4B55]" />
                {t.hero_feature_fresh}
              </span>
              <span aria-hidden="true" className="text-[#D4B2B8]">·</span>
              <span className="flex items-center gap-1.5">
                <Award className="w-4 h-4 text-[#8D4B55]" />
                {t.hero_feature_natural}
              </span>
              <span aria-hidden="true" className="text-[#D4B2B8]">·</span>
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#8D4B55]" />
                {t.hero_feature_delivery}
              </span>
            </div>
          </div>

          {/* Right Column: Interactive 3D Masterpiece Card */}
          <div className="lg:col-span-5 flex justify-center perspective-1000">
            <div
              onMouseMove={handleMouseMove}
              onMouseEnter={() => setIsHovering(true)}
              onMouseLeave={handleMouseLeave}
              style={{
                transform: `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)`,
                transition: isHovering ? 'transform 0.1s ease-out' : 'transform 0.6s cubic-bezier(0.16, 1, 0.3, 1)',
              }}
              className="relative w-full max-w-[420px] rounded-2xl bg-white p-3 border border-[#EBDDD8] luxury-shadow hover:luxury-shadow-hover transition-shadow duration-300 transform-style-3d cursor-pointer group"
              onClick={onExploreClick}
            >
              {/* Image Container */}
              <div className="relative aspect-[4/5] rounded-xl overflow-hidden bg-[#F5EDE9]">
                <img
                  src="/src/assets/images/hero_luxury_cake_1792666086553.jpg"
                  alt="YUM HUB Signature Multi-Tier Cake"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                />

                {/* Subtle scrim at bottom */}
                <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-[#2D1810]/80 via-[#2D1810]/30 to-transparent" />

                {/* Card overlay content */}
                <div className="absolute bottom-4 inset-x-4 text-white">
                  <div className="text-[11px] font-medium tracking-widest uppercase text-[#FDE2E4]">
                    Masterpiece Selection
                  </div>
                  <h3 className="font-display text-lg font-bold tracking-tight text-white mt-0.5">
                    Opulent Blush & Wild Berries
                  </h3>
                  <div className="flex items-center justify-between text-xs text-[#FFF1F2]/90 mt-1 font-light">
                    <span>Hand-gilded 24k Gold Foil</span>
                    <span className="font-mono font-semibold tabular-nums text-white">৳ 6,800</span>
                  </div>
                </div>
              </div>

              {/* Decorative 3D elevated floating depth tag */}
              <div 
                style={{ transform: 'translateZ(30px)' }}
                className="absolute -top-3 -right-3 bg-[#2D1810] text-[#FAF7F2] px-3.5 py-1.5 rounded-lg text-xs font-semibold shadow-lg border border-[#8D4B55]/30 flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#FDE2E4]" />
                <span>3D Artisanal Sculpting</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
