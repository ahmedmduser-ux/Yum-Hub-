import React, { useState, useEffect } from 'react';
import {
  X, ShieldCheck, Lock, LogOut, Package, ShoppingCart, Settings,
  Plus, Edit, Trash2, CheckCircle2, AlertTriangle, Send, RefreshCw,
  Copy, Check, Upload, Search, Filter, Phone, MapPin, Calendar, ExternalLink
} from 'lucide-react';
import { Product, Order, OrderStatus, Language, ShopSettings } from '../types';
import { translations } from '../lib/translations';
import {
  getSupabase,
  isSupabaseConfigured,
  getSupabaseCredentials,
  saveSupabaseCredentials,
  verifyUserIsOwner,
  uploadCakeImageToSupabase
} from '../lib/supabase';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  products: Product[];
  onRefreshProducts: () => void;
  shopSettings: ShopSettings;
  onUpdateShopSettings: (settings: ShopSettings) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  isOpen,
  onClose,
  language,
  products,
  onRefreshProducts,
  shopSettings,
  onUpdateShopSettings,
}) => {
  if (!isOpen) return null;

  const t = translations[language];

  // Supabase Auth State
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [isOwnerVerified, setIsOwnerVerified] = useState<boolean>(false);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [authError, setAuthError] = useState<string | null>(null);

  // Login Form
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [isSigningIn, setIsSigningIn] = useState(false);

  // Tabs: 'orders' | 'products' | 'settings'
  const [activeTab, setActiveTab] = useState<'orders' | 'products' | 'settings'>('orders');

  // Orders State
  const [orders, setOrders] = useState<Order[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(false);
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('all');
  const [orderSearchQuery, setOrderSearchQuery] = useState<string>('');

  // Product Form Modal State
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [productForm, setProductForm] = useState({
    name: '',
    name_bn: '',
    description: '',
    description_bn: '',
    price: 2200,
    category: 'birthday',
    image_url: '',
    is_available: true,
  });
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [productFormError, setProductFormError] = useState<string | null>(null);
  const [isSavingProduct, setIsSavingProduct] = useState(false);

  // Settings State
  const creds = getSupabaseCredentials();
  const [customUrl, setCustomUrl] = useState(creds.url);
  const [customKey, setCustomKey] = useState(creds.anonKey);
  const [settingsSuccess, setSettingsSuccess] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);

  // Check auth session on mount
  useEffect(() => {
    checkCurrentAuth();
  }, [isOpen]);

  const checkCurrentAuth = async () => {
    setAuthLoading(true);
    setAuthError(null);

    const client = getSupabase();
    if (!client) {
      setAuthLoading(false);
      setIsOwnerVerified(false);
      return;
    }

    try {
      const { data: { session } } = await client.auth.getSession();
      if (session?.user) {
        setCurrentUser(session.user);
        // Verify owner role in database (user_roles table via RLS)
        const isOwner = await verifyUserIsOwner(session.user.id);
        if (isOwner) {
          setIsOwnerVerified(true);
          fetchOrders();
        } else {
          setIsOwnerVerified(false);
          setAuthError(t.admin_access_denied);
          await client.auth.signOut();
        }
      } else {
        setCurrentUser(null);
        setIsOwnerVerified(false);
      }
    } catch (err: any) {
      console.error('Auth verification error:', err);
      setIsOwnerVerified(false);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setIsSigningIn(true);

    const client = getSupabase();
    if (!client) {
      setAuthError('Supabase is not configured yet. Please configure your URL & Key in the Settings tab.');
      setIsSigningIn(false);
      return;
    }

    try {
      const { data, error } = await client.auth.signInWithPassword({
        email: loginEmail.trim(),
        password: loginPassword,
      });

      if (error) {
        setAuthError(error.message);
        setIsSigningIn(false);
        return;
      }

      if (data.user) {
        setCurrentUser(data.user);
        // Verify role in user_roles table on database side
        const isOwner = await verifyUserIsOwner(data.user.id);
        if (isOwner) {
          setIsOwnerVerified(true);
          fetchOrders();
        } else {
          setIsOwnerVerified(false);
          setAuthError(t.admin_access_denied);
          await client.auth.signOut();
        }
      }
    } catch (err: any) {
      setAuthError(err.message || 'Authentication error');
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    const client = getSupabase();
    if (client) {
      await client.auth.signOut();
    }
    setCurrentUser(null);
    setIsOwnerVerified(false);
    setOrders([]);
  };

  // Fetch orders from Supabase
  const fetchOrders = async () => {
    const client = getSupabase();
    if (!client) return;

    setOrdersLoading(true);
    try {
      const { data, error } = await client
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching orders:', error.message);
      } else {
        setOrders(data || []);
      }
    } catch (err) {
      console.error('Failed to query orders table:', err);
    } finally {
      setOrdersLoading(false);
    }
  };

  // Update order status in Supabase
  const handleUpdateOrderStatus = async (orderId: string, newStatus: OrderStatus) => {
    const client = getSupabase();
    if (!client) return;

    try {
      const { error } = await client
        .from('orders')
        .update({ status: newStatus })
        .eq('id', orderId);

      if (error) {
        alert(`Failed to update order status: ${error.message}`);
      } else {
        setOrders((prev) =>
          prev.map((o) => (o.id === orderId ? { ...o, status: newStatus } : o))
        );
      }
    } catch (err: any) {
      alert(`Error updating order: ${err.message}`);
    }
  };

  // WhatsApp customer notification for an order
  const handleWhatsAppCustomer = (order: Order) => {
    const msg = `Hello ${order.customer_name}! This is YUM HUB Artisan Bakery regarding your order #${order.id}. Current Status: ${order.status}. Delivery Date: ${order.delivery_date}. Total: ৳${order.total_amount.toLocaleString()}. Please let us know if you need any adjustments!`;
    const cleanPhone = order.customer_phone.replace(/\D/g, '');
    const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  // Open Product Modal for Add / Edit
  const openProductForm = (product?: Product) => {
    if (product) {
      setEditingProduct(product);
      setProductForm({
        name: product.name,
        name_bn: product.name_bn || '',
        description: product.description,
        description_bn: product.description_bn || '',
        price: product.price,
        category: product.category,
        image_url: product.image_url,
        is_available: product.is_available,
      });
    } else {
      setEditingProduct(null);
      setProductForm({
        name: '',
        name_bn: '',
        description: '',
        description_bn: '',
        price: 2200,
        category: 'birthday',
        image_url: '/src/assets/images/cake_chocolate_truffle_1792666087276.jpg',
        is_available: true,
      });
    }
    setProductFormError(null);
    setIsProductModalOpen(true);
  };

  // Handle Image Upload to Supabase Storage
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingImage(true);
    setProductFormError(null);

    const res = await uploadCakeImageToSupabase(file);
    setIsUploadingImage(false);

    if (res.url) {
      setProductForm((prev) => ({ ...prev, image_url: res.url! }));
    } else {
      setProductFormError(`Storage upload notice: ${res.error || 'Failed to upload'}. You can paste an image URL directly.`);
    }
  };

  // Save Product to Supabase
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    const client = getSupabase();
    if (!client) {
      setProductFormError('Supabase is not configured.');
      return;
    }

    setIsSavingProduct(true);
    setProductFormError(null);

    const payload = {
      name: productForm.name.trim(),
      name_bn: productForm.name_bn.trim() || undefined,
      description: productForm.description.trim(),
      description_bn: productForm.description_bn.trim() || undefined,
      price: Number(productForm.price),
      category: productForm.category,
      image_url: productForm.image_url.trim(),
      is_available: productForm.is_available,
      updated_at: new Date().toISOString(),
    };

    try {
      if (editingProduct) {
        const { error } = await client
          .from('products')
          .update(payload)
          .eq('id', editingProduct.id);

        if (error) throw error;
      } else {
        const { error } = await client.from('products').insert([payload]);
        if (error) throw error;
      }

      setIsSavingProduct(false);
      setIsProductModalOpen(false);
      onRefreshProducts();
    } catch (err: any) {
      setIsSavingProduct(false);
      setProductFormError(err.message || 'Failed to save product in database.');
    }
  };

  // Delete Product from Supabase
  const handleDeleteProduct = async (productId: string) => {
    const client = getSupabase();
    if (!client) return;

    try {
      const { error } = await client.from('products').delete().eq('id', productId);
      if (error) {
        alert(`Delete failed: ${error.message}`);
      } else {
        setDeleteConfirmId(null);
        onRefreshProducts();
      }
    } catch (err: any) {
      alert(`Error deleting product: ${err.message}`);
    }
  };

  // Toggle product availability directly
  const handleToggleProductAvailability = async (product: Product) => {
    const client = getSupabase();
    if (!client) return;

    try {
      const { error } = await client
        .from('products')
        .update({ is_available: !product.is_available })
        .eq('id', product.id);

      if (!error) {
        onRefreshProducts();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Save Custom Supabase credentials
  const handleSaveCredentials = (e: React.FormEvent) => {
    e.preventDefault();
    saveSupabaseCredentials(customUrl, customKey);
    setSettingsSuccess(true);
    setTimeout(() => {
      setSettingsSuccess(false);
      checkCurrentAuth();
    }, 1500);
  };

  const copySqlSchema = () => {
    const sql = `-- Supabase SQL Schema for YUM HUB
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS public.user_roles (
    user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (role IN ('owner', 'admin', 'customer')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_owner(check_user_id UUID)
RETURNS BOOLEAN LANGUAGE sql SECURITY DEFINER SET search_path = public STABLE AS $$
    SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = check_user_id AND role = 'owner');
$$;

CREATE POLICY "Users can read own role" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Owners can manage all roles" ON public.user_roles FOR ALL TO authenticated USING (public.is_owner(auth.uid())) WITH CHECK (public.is_owner(auth.uid()));

CREATE TABLE IF NOT EXISTS public.products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    name_bn TEXT,
    description TEXT NOT NULL,
    description_bn TEXT,
    price NUMERIC NOT NULL CHECK (price >= 0),
    category TEXT NOT NULL CHECK (category IN ('birthday', 'chocolate', 'wedding', 'cupcakes', 'anniversary', 'custom')),
    image_url TEXT NOT NULL,
    is_available BOOLEAN NOT NULL DEFAULT true,
    weight_options TEXT[] DEFAULT ARRAY['1 kg (6-8 servings)', '1.5 kg (10-12 servings)', '2 kg (16-18 servings)'],
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can view available cakes" ON public.products FOR SELECT TO anon, authenticated USING (is_available = true OR public.is_owner(auth.uid()));
CREATE POLICY "Only owners can insert cakes" ON public.products FOR INSERT TO authenticated WITH CHECK (public.is_owner(auth.uid()));
CREATE POLICY "Only owners can update cakes" ON public.products FOR UPDATE TO authenticated USING (public.is_owner(auth.uid())) WITH CHECK (public.is_owner(auth.uid()));
CREATE POLICY "Only owners can delete cakes" ON public.products FOR DELETE TO authenticated USING (public.is_owner(auth.uid()));

CREATE TABLE IF NOT EXISTS public.orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_name TEXT NOT NULL,
    customer_phone TEXT NOT NULL,
    delivery_address TEXT NOT NULL,
    delivery_date DATE NOT NULL,
    cake_message TEXT,
    items JSONB NOT NULL,
    total_amount NUMERIC NOT NULL CHECK (total_amount >= 0),
    status TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending', 'Confirmed', 'Preparing', 'Out for Delivery', 'Delivered', 'Cancelled')),
    payment_method TEXT NOT NULL DEFAULT 'Cash on Delivery (Pay at Door)',
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can submit customer order" ON public.orders FOR INSERT TO anon, authenticated WITH CHECK (length(trim(customer_name)) > 0 AND length(trim(customer_phone)) >= 6);
CREATE POLICY "Owners can view customer orders" ON public.orders FOR SELECT TO authenticated USING (public.is_owner(auth.uid()));
CREATE POLICY "Owners can update order status" ON public.orders FOR UPDATE TO authenticated USING (public.is_owner(auth.uid())) WITH CHECK (public.is_owner(auth.uid()));
CREATE POLICY "Owners can delete orders" ON public.orders FOR DELETE TO authenticated USING (public.is_owner(auth.uid()));

-- Insert storage bucket
INSERT INTO storage.buckets (id, name, public) VALUES ('cake-images', 'cake-images', true) ON CONFLICT (id) DO NOTHING;
CREATE POLICY "Public can view cake images" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id = 'cake-images');
CREATE POLICY "Owners can upload cake images" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'cake-images' AND public.is_owner(auth.uid()));
`;
    navigator.clipboard.writeText(sql);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2000);
  };

  // Filter orders
  const filteredOrders = orders.filter((order) => {
    const matchesStatus = orderStatusFilter === 'all' || order.status === orderStatusFilter;
    const matchesSearch =
      order.customer_name.toLowerCase().includes(orderSearchQuery.toLowerCase()) ||
      order.customer_phone.includes(orderSearchQuery);
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-[#2D1810]/70 backdrop-blur-md overflow-y-auto">
      <div 
        className="relative w-full max-w-5xl bg-[#FAF7F2] rounded-2xl shadow-2xl border border-[#EBDDD8] overflow-hidden my-4 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header Bar */}
        <div className="p-4 sm:p-6 border-b border-[#EBDDD8] bg-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-[#2D1810] text-white">
              <ShieldCheck className="w-6 h-6 text-[#FDE2E4]" />
            </div>
            <div>
              <h2 className="font-display text-lg sm:text-xl font-bold text-[#2D1810]">
                {t.admin_title}
              </h2>
              <p className="text-xs text-[#7A5850]">
                {t.admin_subtitle}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {isOwnerVerified && (
              <button
                onClick={handleSignOut}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>{t.admin_logout}</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-[#5D4037] hover:text-[#2D1810] hover:bg-[#FAF7F2] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Auth Barrier: If not verified owner, show Login Screen */}
        {!isOwnerVerified ? (
          <div className="flex-1 p-6 sm:p-12 overflow-y-auto">
            <div className="max-w-md mx-auto bg-white p-6 sm:p-8 rounded-2xl border border-[#EBDDD8] shadow-sm space-y-6">
              
              <div className="text-center space-y-2">
                <div className="w-12 h-12 rounded-full bg-[#FFF5F3] text-[#8D4B55] flex items-center justify-center mx-auto">
                  <Lock className="w-6 h-6" />
                </div>
                <h3 className="font-display text-xl font-bold text-[#2D1810]">
                  {t.admin_login_title}
                </h3>
                <p className="text-xs text-[#7A5850] leading-relaxed">
                  {t.admin_login_desc}
                </p>
              </div>

              {/* Status Notice */}
              <div className="p-3 bg-[#FAF7F2] rounded-lg border border-[#EBDDD8] text-xs text-[#5D4037] space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Supabase Status:</span>
                  <span className={`font-semibold ${isSupabaseConfigured() ? 'text-emerald-700' : 'text-amber-700'}`}>
                    {isSupabaseConfigured() ? 'Connected' : 'Credentials Needed'}
                  </span>
                </div>
              </div>

              {authError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <p>{authError}</p>
                </div>
              )}

              <form onSubmit={handleSignIn} className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-[#2D1810] block mb-1">
                    {t.admin_email}
                  </label>
                  <input
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="owner@yumhub.com"
                    className="w-full px-3.5 py-2 text-xs rounded-lg border border-[#EADED9] focus:outline-none focus:ring-1 focus:ring-[#8D4B55] bg-white text-[#2D1810]"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-[#2D1810] block mb-1">
                    {t.admin_password}
                  </label>
                  <input
                    type="password"
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full px-3.5 py-2 text-xs rounded-lg border border-[#EADED9] focus:outline-none focus:ring-1 focus:ring-[#8D4B55] bg-white text-[#2D1810]"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSigningIn}
                  className="w-full py-2.5 px-4 bg-[#2D1810] hover:bg-[#3E2723] text-white rounded-lg text-xs font-semibold uppercase tracking-wider shadow transition-colors cursor-pointer disabled:opacity-50"
                >
                  {isSigningIn ? t.admin_signing_in : t.admin_sign_in}
                </button>
              </form>

              {/* Quick Setup Assist */}
              <div className="pt-4 border-t border-[#F2E8E4] text-center">
                <button
                  onClick={() => setActiveTab('settings')}
                  className="text-xs text-[#8D4B55] hover:underline font-medium cursor-pointer"
                >
                  Configure Supabase Project Credentials & View SQL Schema
                </button>
              </div>

            </div>
          </div>
        ) : (
          /* Authenticated Owner Workspace */
          <div className="flex-1 flex flex-col overflow-hidden">
            
            {/* Tab Navigation */}
            <div className="px-6 border-b border-[#EBDDD8] bg-white flex gap-6 text-xs font-semibold">
              <button
                onClick={() => setActiveTab('orders')}
                className={`py-3.5 border-b-2 flex items-center gap-2 cursor-pointer transition-colors ${
                  activeTab === 'orders'
                    ? 'border-[#2D1810] text-[#2D1810]'
                    : 'border-transparent text-[#7A5850] hover:text-[#2D1810]'
                }`}
              >
                <ShoppingCart className="w-4 h-4" />
                <span>{t.admin_tab_orders}</span>
                <span className="ml-1 px-1.5 py-0.5 rounded-full bg-[#FAF7F2] text-[#2D1810] text-[10px] font-mono tabular-nums">
                  {orders.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('products')}
                className={`py-3.5 border-b-2 flex items-center gap-2 cursor-pointer transition-colors ${
                  activeTab === 'products'
                    ? 'border-[#2D1810] text-[#2D1810]'
                    : 'border-transparent text-[#7A5850] hover:text-[#2D1810]'
                }`}
              >
                <Package className="w-4 h-4" />
                <span>{t.admin_tab_products}</span>
                <span className="ml-1 px-1.5 py-0.5 rounded-full bg-[#FAF7F2] text-[#2D1810] text-[10px] font-mono tabular-nums">
                  {products.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('settings')}
                className={`py-3.5 border-b-2 flex items-center gap-2 cursor-pointer transition-colors ${
                  activeTab === 'settings'
                    ? 'border-[#2D1810] text-[#2D1810]'
                    : 'border-transparent text-[#7A5850] hover:text-[#2D1810]'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>{t.admin_tab_settings}</span>
              </button>
            </div>

            {/* Tab 1: Orders Management */}
            {activeTab === 'orders' && (
              <div className="flex-1 p-6 overflow-y-auto space-y-4">
                
                {/* Search & Filter Toolbar */}
                <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between bg-white p-3 rounded-xl border border-[#EBDDD8]">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 absolute left-3 top-2.5 text-[#8C6D65]" />
                    <input
                      type="text"
                      value={orderSearchQuery}
                      onChange={(e) => setOrderSearchQuery(e.target.value)}
                      placeholder={t.admin_search_orders}
                      className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-[#EADED9] focus:outline-none focus:ring-1 focus:ring-[#8D4B55] bg-[#FAF7F2] text-[#2D1810]"
                    />
                  </div>

                  <div className="flex items-center gap-2">
                    <Filter className="w-3.5 h-3.5 text-[#8D4B55]" />
                    <select
                      value={orderStatusFilter}
                      onChange={(e) => setOrderStatusFilter(e.target.value)}
                      className="text-xs px-2.5 py-1.5 rounded-lg border border-[#EADED9] bg-[#FAF7F2] text-[#2D1810] font-medium"
                    >
                      <option value="all">All Statuses</option>
                      <option value="Pending">Pending</option>
                      <option value="Confirmed">Confirmed</option>
                      <option value="Preparing">Preparing</option>
                      <option value="Out for Delivery">Out for Delivery</option>
                      <option value="Delivered">Delivered</option>
                      <option value="Cancelled">Cancelled</option>
                    </select>

                    <button
                      onClick={fetchOrders}
                      className="p-1.5 rounded-lg text-[#5D4037] hover:text-[#2D1810] hover:bg-[#FAF7F2] transition-colors cursor-pointer"
                      title="Refresh Orders"
                    >
                      <RefreshCw className={`w-4 h-4 ${ordersLoading ? 'animate-spin' : ''}`} />
                    </button>
                  </div>
                </div>

                {/* Orders Grid/List */}
                {filteredOrders.length === 0 ? (
                  <div className="bg-white rounded-xl border border-[#EBDDD8] p-12 text-center">
                    <ShoppingCart className="w-10 h-10 text-[#8D4B55]/40 mx-auto mb-3" />
                    <p className="text-sm font-semibold text-[#2D1810]">{t.admin_no_orders}</p>
                    <p className="text-xs text-[#7A5850] mt-1">Customer orders placed online will appear here in real time.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredOrders.map((order) => (
                      <div
                        key={order.id}
                        className="bg-white rounded-xl border border-[#EBDDD8] p-5 shadow-sm space-y-4"
                      >
                        {/* Order Header */}
                        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#F2E8E4] pb-3">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-xs font-bold text-[#8D4B55]">
                                #{order.id.slice(0, 8)}
                              </span>
                              <span className="text-xs font-semibold text-[#2D1810]">
                                {order.customer_name}
                              </span>
                            </div>
                            <span className="text-[11px] text-[#8C6D65]">
                              {order.created_at ? new Date(order.created_at).toLocaleString() : ''}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            {/* Status dropdown */}
                            <select
                              value={order.status}
                              onChange={(e) => handleUpdateOrderStatus(order.id, e.target.value as OrderStatus)}
                              className={`text-xs px-2.5 py-1 rounded-md font-semibold border cursor-pointer ${
                                order.status === 'Delivered'
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                  : order.status === 'Pending'
                                  ? 'bg-amber-50 text-amber-800 border-amber-200'
                                  : order.status === 'Cancelled'
                                  ? 'bg-rose-50 text-rose-800 border-rose-200'
                                  : 'bg-blue-50 text-blue-800 border-blue-200'
                              }`}
                            >
                              <option value="Pending">Pending</option>
                              <option value="Confirmed">Confirmed</option>
                              <option value="Preparing">Preparing</option>
                              <option value="Out for Delivery">Out for Delivery</option>
                              <option value="Delivered">Delivered</option>
                              <option value="Cancelled">Cancelled</option>
                            </select>

                            {/* WhatsApp Button */}
                            <button
                              onClick={() => handleWhatsAppCustomer(order)}
                              className="flex items-center gap-1 px-2.5 py-1 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-md text-xs font-semibold transition-colors cursor-pointer"
                              title="Chat with Customer on WhatsApp"
                            >
                              <Send className="w-3 h-3" />
                              <span className="hidden sm:inline">WhatsApp</span>
                            </button>
                          </div>
                        </div>

                        {/* Order Details Body */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-[#5D4037]">
                          {/* Contact & Delivery */}
                          <div className="space-y-1.5">
                            <div className="flex items-center gap-1.5 font-medium text-[#2D1810]">
                              <Phone className="w-3.5 h-3.5 text-[#8D4B55]" />
                              <span>{order.customer_phone}</span>
                            </div>
                            <div className="flex items-start gap-1.5">
                              <MapPin className="w-3.5 h-3.5 text-[#8D4B55] shrink-0 mt-0.5" />
                              <span className="leading-tight">{order.delivery_address}</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <Calendar className="w-3.5 h-3.5 text-[#8D4B55]" />
                              <span>Delivery Date: <strong className="text-[#2D1810]">{order.delivery_date}</strong></span>
                            </div>
                          </div>

                          {/* Cake Inscription / Message */}
                          <div className="p-3 bg-[#FAF7F2] rounded-lg border border-[#EBDDD8]">
                            <span className="text-[11px] font-semibold uppercase tracking-wider text-[#8D4B55] block mb-1">
                              Cake Inscription:
                            </span>
                            <p className="text-xs italic text-[#2D1810]">
                              {order.cake_message ? `"${order.cake_message}"` : 'No custom inscription requested'}
                            </p>
                          </div>

                          {/* Items & Amount */}
                          <div className="flex flex-col justify-between">
                            <div>
                              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#8D4B55] block mb-1">
                                Ordered Items:
                              </span>
                              <div className="space-y-1">
                                {Array.isArray(order.items) &&
                                  order.items.map((it: any, i: number) => (
                                    <div key={i} className="flex justify-between text-[11px]">
                                      <span>{it.name} {it.weight ? `(${it.weight})` : ''} x {it.quantity}</span>
                                      <span className="font-mono tabular-nums">৳{(it.price * it.quantity).toLocaleString()}</span>
                                    </div>
                                  ))}
                              </div>
                            </div>
                            <div className="pt-2 border-t border-[#F2E8E4] flex justify-between font-bold text-xs text-[#2D1810]">
                              <span>Total:</span>
                              <span className="font-mono tabular-nums text-sm">৳{Number(order.total_amount).toLocaleString()}</span>
                            </div>
                          </div>
                        </div>

                      </div>
                    ))}
                  </div>
                )}

              </div>
            )}

            {/* Tab 2: Products Catalog CRUD */}
            {activeTab === 'products' && (
              <div className="flex-1 p-6 overflow-y-auto space-y-4">
                
                {/* Product Toolbar */}
                <div className="flex justify-between items-center bg-white p-3 rounded-xl border border-[#EBDDD8]">
                  <span className="text-xs font-semibold text-[#5D4037]">
                    Total Catalog Cakes: <strong>{products.length}</strong>
                  </span>
                  <button
                    onClick={() => openProductForm()}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-[#2D1810] hover:bg-[#3E2723] text-white rounded-lg text-xs font-semibold uppercase tracking-wider shadow transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{t.admin_add_product}</span>
                  </button>
                </div>

                {/* Products Table */}
                <div className="bg-white rounded-xl border border-[#EBDDD8] overflow-hidden shadow-sm">
                  <table className="w-full text-left text-xs text-[#2D1810]">
                    <thead className="bg-[#FAF7F2] border-b border-[#EBDDD8] text-[#7A5850] uppercase font-semibold">
                      <tr>
                        <th className="p-3">Cake</th>
                        <th className="p-3">Category</th>
                        <th className="p-3">Price</th>
                        <th className="p-3">Status</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#F2E8E4]">
                      {products.map((product) => (
                        <tr key={product.id} className="hover:bg-[#FAF7F2]/50 transition-colors">
                          <td className="p-3">
                            <div className="flex items-center gap-3">
                              <img
                                src={product.image_url}
                                alt={product.name}
                                referrerPolicy="no-referrer"
                                className="w-10 h-10 rounded-lg object-cover bg-[#FAF7F2]"
                              />
                              <div>
                                <span className="font-semibold block">{product.name}</span>
                                {product.name_bn && (
                                  <span className="text-[11px] text-[#8C6D65]">{product.name_bn}</span>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="p-3 capitalize text-[#7A5850]">
                            {product.category}
                          </td>
                          <td className="p-3 font-mono font-bold tabular-nums">
                            ৳ {product.price.toLocaleString()}
                          </td>
                          <td className="p-3">
                            <button
                              onClick={() => handleToggleProductAvailability(product)}
                              className={`px-2 py-0.5 rounded text-[11px] font-semibold cursor-pointer ${
                                product.is_available
                                  ? 'bg-emerald-50 text-emerald-700'
                                  : 'bg-rose-50 text-rose-700'
                              }`}
                            >
                              {product.is_available ? t.in_stock : t.out_of_stock}
                            </button>
                          </td>
                          <td className="p-3 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => openProductForm(product)}
                                className="p-1 text-[#5D4037] hover:text-[#2D1810] transition-colors cursor-pointer"
                                title="Edit Cake"
                              >
                                <Edit className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => setDeleteConfirmId(product.id)}
                                className="p-1 text-[#A07066] hover:text-rose-600 transition-colors cursor-pointer"
                                title="Delete Cake"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

              </div>
            )}

            {/* Tab 3: Supabase & Shop Settings */}
            {activeTab === 'settings' && (
              <div className="flex-1 p-6 overflow-y-auto space-y-6">
                
                {/* Supabase Connection Setup */}
                <div className="bg-white p-6 rounded-xl border border-[#EBDDD8] shadow-sm space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-display text-base font-bold text-[#2D1810]">
                        Supabase Project Connection
                      </h3>
                      <p className="text-xs text-[#7A5850]">
                        Enter your Supabase project credentials. These connect to your cloud database and authentication.
                      </p>
                    </div>
                    <span className={`text-xs px-2.5 py-1 rounded-md font-semibold ${
                      isSupabaseConfigured() ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-800'
                    }`}>
                      {isSupabaseConfigured() ? 'Connected' : 'Not Connected'}
                    </span>
                  </div>

                  {settingsSuccess && (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Credentials saved successfully. Reconnecting...</span>
                    </div>
                  )}

                  <form onSubmit={handleSaveCredentials} className="space-y-4">
                    <div>
                      <label className="text-xs font-semibold text-[#2D1810] block mb-1">
                        VITE_SUPABASE_URL
                      </label>
                      <input
                        type="url"
                        value={customUrl}
                        onChange={(e) => setCustomUrl(e.target.value)}
                        placeholder="https://your-project-id.supabase.co"
                        className="w-full px-3.5 py-2 text-xs rounded-lg border border-[#EADED9] font-mono text-[#2D1810] bg-white focus:outline-none focus:ring-1 focus:ring-[#8D4B55]"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-[#2D1810] block mb-1">
                        VITE_SUPABASE_ANON_KEY
                      </label>
                      <input
                        type="password"
                        value={customKey}
                        onChange={(e) => setCustomKey(e.target.value)}
                        placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                        className="w-full px-3.5 py-2 text-xs rounded-lg border border-[#EADED9] font-mono text-[#2D1810] bg-white focus:outline-none focus:ring-1 focus:ring-[#8D4B55]"
                      />
                    </div>

                    <div className="flex gap-3">
                      <button
                        type="submit"
                        className="py-2 px-4 bg-[#2D1810] hover:bg-[#3E2723] text-white rounded-lg text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer"
                      >
                        Save & Apply Credentials
                      </button>
                    </div>
                  </form>
                </div>

                {/* SQL Migration Script & RLS Copy */}
                <div className="bg-white p-6 rounded-xl border border-[#EBDDD8] shadow-sm space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-display text-base font-bold text-[#2D1810]">
                        Supabase SQL Migration & RLS Security Script
                      </h3>
                      <p className="text-xs text-[#7A5850]">
                        Run this script in your Supabase SQL Editor to create tables, storage buckets, and secure RLS policies.
                      </p>
                    </div>

                    <button
                      onClick={copySqlSchema}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-[#FAF7F2] hover:bg-[#EBDDD8] text-[#2D1810] rounded-lg text-xs font-semibold border border-[#EADED9] transition-colors cursor-pointer"
                    >
                      {copiedSql ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedSql ? 'Copied SQL!' : 'Copy SQL Script'}</span>
                    </button>
                  </div>

                  <div className="p-3 bg-[#FAF7F2] rounded-lg text-xs text-[#5D4037] space-y-2">
                    <p className="font-semibold text-[#2D1810]">
                      How to grant yourself the "owner" role in Supabase:
                    </p>
                    <ol className="list-decimal list-inside space-y-1 text-[11px] text-[#7A5850]">
                      <li>Open Supabase Dashboard &gt; Authentication &gt; Users.</li>
                      <li>Copy your user account's UUID.</li>
                      <li>Go to SQL Editor and run:</li>
                    </ol>
                    <pre className="p-2.5 bg-[#2D1810] text-[#FDE2E4] rounded font-mono text-[11px] overflow-x-auto">
{`INSERT INTO public.user_roles (user_id, role)
VALUES ('PASTE-YOUR-USER-UUID-HERE', 'owner')
ON CONFLICT (user_id) DO UPDATE SET role = 'owner';`}
                    </pre>
                  </div>
                </div>

                {/* Shop WhatsApp Configuration */}
                <div className="bg-white p-6 rounded-xl border border-[#EBDDD8] shadow-sm space-y-4">
                  <h3 className="font-display text-base font-bold text-[#2D1810]">
                    Shop & WhatsApp Contact Settings
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-semibold text-[#2D1810] block mb-1">
                        Bakery WhatsApp Number (International format, no +)
                      </label>
                      <input
                        type="text"
                        value={shopSettings.whatsapp_number}
                        onChange={(e) =>
                          onUpdateShopSettings({
                            ...shopSettings,
                            whatsapp_number: e.target.value,
                          })
                        }
                        placeholder="8801700000000"
                        className="w-full px-3.5 py-2 text-xs rounded-lg border border-[#EADED9] text-[#2D1810] bg-white focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-[#2D1810] block mb-1">
                        Shop Phone / Helpline
                      </label>
                      <input
                        type="text"
                        value={shopSettings.phone}
                        onChange={(e) =>
                          onUpdateShopSettings({
                            ...shopSettings,
                            phone: e.target.value,
                          })
                        }
                        placeholder="+880 1712 345678"
                        className="w-full px-3.5 py-2 text-xs rounded-lg border border-[#EADED9] text-[#2D1810] bg-white focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

              </div>
            )}

          </div>
        )}

      </div>

      {/* Product Add / Edit Modal */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-[#2D1810]/70 backdrop-blur-sm">
          <div 
            className="w-full max-w-lg bg-white rounded-2xl p-6 border border-[#EBDDD8] shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center border-b border-[#F2E8E4] pb-3">
              <h3 className="font-display text-lg font-bold text-[#2D1810]">
                {editingProduct ? t.admin_edit_product : t.admin_add_product}
              </h3>
              <button
                onClick={() => setIsProductModalOpen(false)}
                className="p-1 rounded-lg text-[#5D4037] hover:bg-[#FAF7F2]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {productFormError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800">
                {productFormError}
              </div>
            )}

            <form onSubmit={handleSaveProduct} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-[#2D1810] block mb-1">
                  {t.admin_product_name}
                </label>
                <input
                  type="text"
                  required
                  value={productForm.name}
                  onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                  placeholder="e.g., Belgian Dark Truffle Cake"
                  className="w-full px-3.5 py-2 text-xs rounded-lg border border-[#EADED9] text-[#2D1810]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#2D1810] block mb-1">
                  {t.admin_product_name_bn}
                </label>
                <input
                  type="text"
                  value={productForm.name_bn}
                  onChange={(e) => setProductForm({ ...productForm, name_bn: e.target.value })}
                  placeholder="যেমন: বেলজিয়ান ডার্ক ট্রাফেল কেক"
                  className="w-full px-3.5 py-2 text-xs rounded-lg border border-[#EADED9] text-[#2D1810]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-[#2D1810] block mb-1">
                    {t.admin_product_price}
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={productForm.price}
                    onChange={(e) => setProductForm({ ...productForm, price: Number(e.target.value) })}
                    className="w-full px-3.5 py-2 text-xs rounded-lg border border-[#EADED9] font-mono text-[#2D1810]"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-[#2D1810] block mb-1">
                    {t.admin_product_category}
                  </label>
                  <select
                    value={productForm.category}
                    onChange={(e) => setProductForm({ ...productForm, category: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs rounded-lg border border-[#EADED9] text-[#2D1810]"
                  >
                    <option value="birthday">Birthday Cakes</option>
                    <option value="chocolate">Chocolate Truffle</option>
                    <option value="wedding">Wedding & Grand</option>
                    <option value="cupcakes">Artisan Cupcakes</option>
                    <option value="anniversary">Anniversary</option>
                    <option value="custom">Custom & Special</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-[#2D1810] block mb-1">
                  {t.admin_product_desc}
                </label>
                <textarea
                  rows={2}
                  required
                  value={productForm.description}
                  onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                  className="w-full px-3.5 py-2 text-xs rounded-lg border border-[#EADED9] text-[#2D1810] resize-none"
                />
              </div>

              {/* Image Input and Upload */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-[#2D1810] block">
                  {t.admin_product_image_url}
                </label>
                <input
                  type="text"
                  required
                  value={productForm.image_url}
                  onChange={(e) => setProductForm({ ...productForm, image_url: e.target.value })}
                  placeholder="https://... or /src/assets/images/..."
                  className="w-full px-3.5 py-2 text-xs rounded-lg border border-[#EADED9] text-[#2D1810]"
                />

                <div className="flex items-center gap-2">
                  <label className="flex items-center gap-1.5 px-3 py-1.5 bg-[#FAF7F2] hover:bg-[#EBDDD8] text-[#2D1810] rounded-lg text-xs font-medium border border-[#EADED9] cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{isUploadingImage ? t.admin_uploading : t.admin_product_upload}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      disabled={isUploadingImage}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="avail"
                  checked={productForm.is_available}
                  onChange={(e) => setProductForm({ ...productForm, is_available: e.target.checked })}
                  className="rounded text-[#2D1810] focus:ring-[#8D4B55]"
                />
                <label htmlFor="avail" className="text-xs font-medium text-[#2D1810]">
                  {t.admin_product_available}
                </label>
              </div>

              <div className="pt-3 border-t border-[#F2E8E4] flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-[#5D4037] hover:bg-[#FAF7F2] rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingProduct}
                  className="px-5 py-2 bg-[#2D1810] hover:bg-[#3E2723] text-white rounded-lg text-xs font-semibold uppercase tracking-wider shadow cursor-pointer disabled:opacity-50"
                >
                  {isSavingProduct ? t.admin_saving_product : t.admin_save_product}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-70 flex items-center justify-center p-4 bg-[#2D1810]/70 backdrop-blur-sm">
          <div className="bg-white rounded-xl p-6 max-w-sm w-full space-y-4 border border-[#EBDDD8] shadow-2xl">
            <h4 className="font-display text-base font-bold text-[#2D1810]">
              {t.admin_delete_product}
            </h4>
            <p className="text-xs text-[#7A5850]">
              {t.admin_confirm_delete}
            </p>
            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 text-xs font-medium text-[#5D4037] hover:bg-[#FAF7F2] rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDeleteProduct(deleteConfirmId)}
                className="px-4 py-2 bg-rose-700 hover:bg-rose-800 text-white text-xs font-semibold rounded-lg shadow cursor-pointer"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
