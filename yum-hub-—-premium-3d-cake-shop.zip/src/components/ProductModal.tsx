import React, { useState } from 'react';
import { X, ShoppingBag, Check, ShieldCheck, Heart, Sparkles } from 'lucide-react';
import { Product, Language } from '../types';
import { translations } from '../lib/translations';

interface ProductModalProps {
  product: Product | null;
  language: Language;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number, weight?: string) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  language,
  onClose,
  onAddToCart,
}) => {
  if (!product) return null;

  const t = translations[language];
  const [quantity, setQuantity] = useState(1);
  const [selectedWeight, setSelectedWeight] = useState<string>(
    product.weight_options && product.weight_options[0] ? product.weight_options[0] : '1 kg'
  );
  const [added, setAdded] = useState(false);

  const displayName = language === 'bn' && product.name_bn ? product.name_bn : product.name;
  const displayDesc = language === 'bn' && product.description_bn ? product.description_bn : product.description;

  const handleAdd = () => {
    onAddToCart(product, quantity, selectedWeight);
    setAdded(true);
    setTimeout(() => {
      setAdded(false);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#2D1810]/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-[#EBDDD8] overflow-hidden flex flex-col md:flex-row max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 rounded-full bg-white/80 hover:bg-white text-[#2D1810] shadow-sm transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Product Image Section */}
        <div className="md:w-1/2 relative bg-[#FAF7F2] min-h-[260px] md:min-h-full">
          <img
            src={product.image_url}
            alt={displayName}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute bottom-3 left-3 bg-[#2D1810]/75 backdrop-blur-md text-[#FFF1F2] px-3 py-1 rounded-md text-xs font-medium flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#FDE2E4]" />
            <span className="capitalize">{product.category} Collection</span>
          </div>
        </div>

        {/* Product Details Section */}
        <div className="md:w-1/2 p-6 flex flex-col justify-between overflow-y-auto">
          <div className="space-y-4">
            {/* Header info */}
            <div>
              <span className="text-xs uppercase tracking-widest font-semibold text-[#8D4B55]">
                YUM HUB Signature
              </span>
              <h2 className="font-display text-2xl font-bold text-[#2D1810] mt-1 leading-snug">
                {displayName}
              </h2>
              <div className="mt-2 text-xl font-bold font-mono tabular-nums text-[#2D1810]">
                ৳ {(product.price * quantity).toLocaleString()}
              </div>
            </div>

            {/* Description */}
            <p className="text-sm text-[#5D4037] leading-relaxed font-light">
              {displayDesc}
            </p>

            {/* Size / Weight Selector */}
            {product.weight_options && product.weight_options.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-[#F2E8E4]">
                <label className="text-xs font-semibold text-[#2D1810] block">
                  {t.weight_label}
                </label>
                <div className="grid grid-cols-1 gap-1.5">
                  {product.weight_options.map((weight) => (
                    <button
                      key={weight}
                      type="button"
                      onClick={() => setSelectedWeight(weight)}
                      className={`px-3 py-2 text-xs font-medium text-left rounded-lg border transition-all cursor-pointer ${
                        selectedWeight === weight
                          ? 'border-[#2D1810] bg-[#FAF7F2] text-[#2D1810] font-semibold ring-1 ring-[#2D1810]'
                          : 'border-[#EADED9] text-[#6B534E] hover:border-[#8D4B55]'
                      }`}
                    >
                      {weight}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Artisan notes */}
            <div className="p-3 bg-[#FFF5F3] rounded-lg border border-[#FDE2E4] text-xs text-[#7A5850] space-y-1">
              <div className="font-medium text-[#8D4B55] flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>{t.modal_description_title}</span>
              </div>
              <p className="text-[11px] leading-relaxed">{t.modal_ingredients}</p>
              <p className="text-[11px] text-[#A07066]">{t.modal_storage}</p>
            </div>
          </div>

          {/* Action Row */}
          <div className="pt-6 mt-4 border-t border-[#F2E8E4] flex items-center gap-3">
            {/* Quantity Controls */}
            <div className="flex items-center border border-[#EADED9] rounded-lg bg-[#FAF7F2]">
              <button
                type="button"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-8 h-9 flex items-center justify-center text-sm font-bold text-[#2D1810] hover:bg-[#EBDDD8] rounded-l-lg transition-colors cursor-pointer"
              >
                -
              </button>
              <span className="w-10 text-center font-mono text-sm font-semibold text-[#2D1810] tabular-nums">
                {quantity}
              </span>
              <button
                type="button"
                onClick={() => setQuantity(quantity + 1)}
                className="w-8 h-9 flex items-center justify-center text-sm font-bold text-[#2D1810] hover:bg-[#EBDDD8] rounded-r-lg transition-colors cursor-pointer"
              >
                +
              </button>
            </div>

            {/* Add Button */}
            <button
              onClick={handleAdd}
              disabled={!product.is_available}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer ${
                !product.is_available
                  ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                  : added
                  ? 'bg-green-700 text-white'
                  : 'bg-[#2D1810] hover:bg-[#3E2723] text-white shadow-md'
              }`}
            >
              {added ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Added to Bag</span>
                </>
              ) : (
                <>
                  <ShoppingBag className="w-4 h-4" />
                  <span>{t.add_to_bag}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
