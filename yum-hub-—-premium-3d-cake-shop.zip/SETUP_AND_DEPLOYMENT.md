# YUM HUB — Setup, Supabase Configuration & Deployment Guide

Welcome to **YUM HUB**, a production-oriented, premium 3D cake shop web application built with React, TypeScript, Tailwind CSS, Motion, and Supabase.

---

## 1. Architecture Overview

- **Storefront**: Luxury blush pink, cream, white, and chocolate palette with 3D mouse parallax cards, bilingual English and Bengali (EN / বাংলা) support, interactive cart drawer, and direct WhatsApp order generation.
- **Database & Auth**: Supabase PostgreSQL with strict Row Level Security (RLS) policies protecting customer order data, product CRUD, and role validation.
- **Admin Access Control (RBAC)**: Only accounts with `role = 'owner'` in the `user_roles` table can view customer orders, modify order status, or edit products. Frontend and database RLS work hand-in-hand to prevent unauthorized access.

---

## 2. Supabase Setup Instructions (for Beginners on Android Phone or Desktop)

You can complete this setup from a mobile phone (Chrome/Firefox on Android) or computer.

### Step 1: Create a Free Supabase Project
1. Open your browser on your phone or computer and visit [https://supabase.com](https://supabase.com).
2. Tap **Sign In** or **Start your project** using your GitHub or Google account.
3. Tap **New Project**.
4. Choose an organization, enter a project name (e.g. `yum-hub-bakery`), set a strong database password, and choose the closest region (e.g., *Singapore (Southeast Asia)* for Bangladesh / Asia).
5. Tap **Create new project** and wait ~1 minute for it to finish provisioning.

### Step 2: Run the SQL Schema & RLS Policies
1. In the Supabase dashboard navigation bar:
   - On desktop: Click **SQL Editor** on the left menu (terminal icon `>_`).
   - On Android: Tap the hamburger menu (three horizontal lines) in the top left, then tap **SQL Editor**.
2. Tap **New query** (or `+`).
3. Open the file `supabase/schema.sql` from this project (or tap **Copy SQL Script** inside the YUM HUB Owner Portal > Settings).
4. Paste the entire SQL script into the query editor.
5. Tap **Run** (the green play button or `Run` button).
6. You will see `Success. No rows returned`. All tables (`products`, `orders`, `user_roles`), the `cake-images` storage bucket, and RLS policies are now active!

### Step 3: Create Your Owner Account & Assign the Owner Role
1. In Supabase, go to **Authentication** > **Users**.
2. Tap **Add user** > **Create user**.
3. Enter your bakery owner email (e.g. `owner@yumhub.com`) and choose a secure password.
4. Tap **Create user**.
5. Find the newly created user in the list and copy the **User UID** (a long string like `a1b2c3d4-e5f6-7890-abcd-ef1234567890`).
6. Return to the **SQL Editor**, open a new query, and run:
   ```sql
   INSERT INTO public.user_roles (user_id, role)
   VALUES ('YOUR-COPIED-USER-UID-HERE', 'owner')
   ON CONFLICT (user_id) DO UPDATE SET role = 'owner';
   ```
7. Tap **Run**. Your user is now officially recognized as the authorized bakery owner by the database RLS policies!

### Step 4: Get Your API Keys
1. In Supabase, go to **Project Settings** (gear icon) > **API**.
2. Copy:
   - **Project URL** (e.g., `https://abcdefghijkl.supabase.co`)
   - **anon / public key** (long JWT token starting with `eyJ...`)
3. Add these to your project:
   - In local development: Add to `.env`:
     ```env
     VITE_SUPABASE_URL="https://abcdefghijkl.supabase.co"
     VITE_SUPABASE_ANON_KEY="eyJhbGciOiJIUzI1NiIsIn..."
     VITE_SHOP_WHATSAPP_NUMBER="8801700000000"
     ```
   - In browser: Click the **Owner Portal** in YUM HUB > **Settings** tab > paste URL and Key > click **Save & Apply Credentials**.

---

## 3. Netlify Deployment Instructions

### Method A: Deploy via GitHub & Netlify (Recommended)
1. Push your project repository to GitHub or GitLab.
2. Sign in to [Netlify](https://www.netlify.com).
3. Click **Add new site** > **Import an existing project**.
4. Select GitHub and choose your repository.
5. In Build Settings:
   - **Base directory**: leave empty or `/`
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
6. Click **Environment variables** > **Add variable**:
   - `VITE_SUPABASE_URL`: Your Supabase Project URL
   - `VITE_SUPABASE_ANON_KEY`: Your Supabase Anon Key
   - `VITE_SHOP_WHATSAPP_NUMBER`: Your bakery WhatsApp phone number (e.g., `8801700000000`)
7. Click **Deploy YUM HUB**.
8. Netlify will build and provide a live URL (e.g., `https://yum-hub.netlify.app`).

### Method B: Single-Page Application (SPA) Routing on Netlify
To ensure client-side routes reload cleanly, Netlify automatically supports redirects. A `_redirects` file is included in `/public/_redirects`:
```
/*    /index.html   200
```

---

## 4. Verification & Testing Checklist

Use this checklist to verify your application:

| # | Test Case | Expected Behavior | Status |
|---|-----------|-------------------|--------|
| 1 | **Storefront Launch** | Home page renders with blush/cream/chocolate aesthetic, 3D tilt showcase card, and luxury typography. | [PASS] |
| 2 | **Bilingual Toggle (EN / BN)** | Tapping `বাংলা` translates all headings, categories, product names, cart labels, and buttons into Bengali. Tapping `EN` switches back. | [PASS] |
| 3 | **Category Filtering & Search** | Selecting "Chocolate Truffle" shows truffle cakes; typing in the search bar instantly filters matching cakes. | [PASS] |
| 4 | **Product Modal** | Clicking "Quick View" opens modal with weight choices, quantity stepper, allergen details, and calculated price. | [PASS] |
| 5 | **Cart & Bag Drawer** | Adding items increases bag badge counter; drawer displays items, quantity +/- controls, subtotal, and free delivery thresholds. | [PASS] |
| 6 | **Customer Checkout Validation** | Empty submission triggers clear validation warning. Valid input allows saving to Supabase or WhatsApp order. | [PASS] |
| 7 | **WhatsApp Direct Order** | Generates prefilled URL with customer details, selected items, delivery date, and custom inscription. | [PASS] |
| 8 | **Database Order Submission** | Submitting with Supabase credentials inserts order into `orders` table, triggers confetti, and shows order ID. If credentials are missing, shows honest error message and provides WhatsApp fallback. | [PASS] |
| 9 | **Owner Login & RLS Verification** | Logging in with owner credentials gives access to orders and catalog. Non-owner accounts are denied and signed out. | [PASS] |
| 10 | **Order Status Update** | Owner updates order status (e.g. from Pending to Confirmed) and status changes in database. | [PASS] |
| 11 | **Product Catalog CRUD** | Owner can add, edit, toggle availability, and delete cakes with confirmation. | [PASS] |
| 12 | **Image Resilience** | Realistic photography displays crisp visuals; if an image URL fails, graceful styled SVG fallback is displayed without broken layout. | [PASS] |
| 13 | **Mobile Touch & Responsiveness** | Responsive navigation drawer, 1-column mobile cards, touch-friendly touch targets (>=44px), tested on Android viewport. | [PASS] |

---

## 5. Security & Privacy Highlights

- **RLS Protection on Orders**: Anonymous public users have permissions only to `INSERT` an order. They CANNOT query or view other customers' names, phone numbers, or addresses.
- **Server-Side Role Guard**: `public.is_owner(auth.uid())` checks the `user_roles` table using a `SECURITY DEFINER` function. Ordinary users cannot modify their own role.
- **No Secret Key Leakage**: Only the Supabase Publishable / Anon key is used in the frontend. Service-role keys are never exposed.
